<?php

/* AcmeDemoBundle:Welcome:index.html.twig */
class __TwigTemplate_ec05827f9fbefb50e68c26773d9e21af915c70c54cc3bef42f9a69685378a7eb extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = $this->env->loadTemplate("AcmeDemoBundle::layout.html.twig");

        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'content_header' => array($this, 'block_content_header'),
            'content' => array($this, 'block_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "AcmeDemoBundle::layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    public function block_title($context, array $blocks = array())
    {
        echo "Symfony - Welcome";
    }

    // line 5
    public function block_content_header($context, array $blocks = array())
    {
        echo "";
    }

    // line 7
    public function block_content($context, array $blocks = array())
    {
        // line 8
        echo "    ";
        $context["version"] = ((twig_constant("Symfony\\Component\\HttpKernel\\Kernel::MAJOR_VERSION") . ".") . twig_constant("Symfony\\Component\\HttpKernel\\Kernel::MINOR_VERSION"));
        // line 9
        echo "
    <h1 class=\"title\">Welcome!</h1>

    <p>Congratulations! You have successfully installed a new Symfony application.</p>

    <div class=\"symfony-blocks-welcome\">
        <div class=\"block-quick-tour\">
            <div class=\"illustration\">
                <img src=\"";
        // line 17
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("bundles/acmedemo/images/welcome-quick-tour.gif"), "html", null, true);
        echo "\" alt=\"Quick tour\" />
            </div>
            <a href=\"http://symfony.com/doc/";
        // line 19
        echo twig_escape_filter($this->env, (isset($context["version"]) ? $context["version"] : $this->getContext($context, "version")), "html", null, true);
        echo "/quick_tour/index.html\" class=\"sf-button sf-button-selected\">
                <span class=\"border-l\">
                    <span class=\"border-r\">
                        <span class=\"btn-bg\">Read the Quick Tour</span>
                    </span>
                </span>
            </a>
        </div>
        ";
        // line 27
        if (($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "environment") == "dev")) {
            // line 28
            echo "            <div class=\"block-configure\">
                <div class=\"illustration\">
                    <img src=\"";
            // line 30
            echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("bundles/acmedemo/images/welcome-configure.gif"), "html", null, true);
            echo "\" alt=\"Configure your application\" />
                </div>
                <a href=\"";
            // line 32
            echo $this->env->getExtension('routing')->getPath("_configurator_home");
            echo "\" class=\"sf-button sf-button-selected\">
                    <span class=\"border-l\">
                        <span class=\"border-r\">
                            <span class=\"btn-bg\">Configure</span>
                        </span>
                    </span>
                </a>
            </div>
        ";
        }
        // line 41
        echo "        <div class=\"block-demo\">
            <div class=\"illustration\">
                <img src=\"";
        // line 43
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("bundles/acmedemo/images/welcome-demo.gif"), "html", null, true);
        echo "\" alt=\"Demo\" />
            </div>
            <a href=\"";
        // line 45
        echo $this->env->getExtension('routing')->getPath("_demo");
        echo "\" class=\"sf-button sf-button-selected\">
                <span class=\"border-l\">
                    <span class=\"border-r\">
                        <span class=\"btn-bg\">Run The Demo</span>
                    </span>
                </span>
            </a>
        </div>
    </div>

    <div class=\"symfony-blocks-help\">
        <div class=\"block-documentation\">
            <ul>
                <li><strong>Documentation</strong></li>
                <li><a href=\"http://symfony.com/doc/";
        // line 59
        echo twig_escape_filter($this->env, (isset($context["version"]) ? $context["version"] : $this->getContext($context, "version")), "html", null, true);
        echo "/book/index.html\">The Book</a></li>
                <li><a href=\"http://symfony.com/doc/";
        // line 60
        echo twig_escape_filter($this->env, (isset($context["version"]) ? $context["version"] : $this->getContext($context, "version")), "html", null, true);
        echo "/cookbook/index.html\">The Cookbook</a></li>
                <li><a href=\"http://symfony.com/doc/";
        // line 61
        echo twig_escape_filter($this->env, (isset($context["version"]) ? $context["version"] : $this->getContext($context, "version")), "html", null, true);
        echo "/components/index.html\">The Components</a></li>
                <li><a href=\"http://symfony.com/doc/";
        // line 62
        echo twig_escape_filter($this->env, (isset($context["version"]) ? $context["version"] : $this->getContext($context, "version")), "html", null, true);
        echo "/reference/index.html\">Reference</a></li>
                <li><a href=\"http://symfony.com/doc/";
        // line 63
        echo twig_escape_filter($this->env, (isset($context["version"]) ? $context["version"] : $this->getContext($context, "version")), "html", null, true);
        echo "/glossary.html\">Glossary</a></li>
            </ul>
        </div>
        <div class=\"block-documentation-more\">
            <ul>
                <li><strong>Sensio</strong></li>
                <li><a href=\"http://trainings.sensiolabs.com\">Trainings</a></li>
                <li><a href=\"http://books.sensiolabs.com\">Books</a></li>
            </ul>
        </div>
        <div class=\"block-community\">
            <ul>
                <li><strong>Community</strong></li>
                <li><a href=\"http://symfony.com/irc\">IRC channel</a></li>
                <li><a href=\"http://symfony.com/mailing-lists\">Mailing lists</a></li>
                <li><a href=\"http://forum.symfony-project.org\">Forum</a></li>
                <li><a href=\"http://symfony.com/doc/";
        // line 79
        echo twig_escape_filter($this->env, (isset($context["version"]) ? $context["version"] : $this->getContext($context, "version")), "html", null, true);
        echo "/contributing/index.html\">Contributing</a></li>
            </ul>
        </div>
    </div>
";
    }

    public function getTemplateName()
    {
        return "AcmeDemoBundle:Welcome:index.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  97 => 41,  58 => 17,  127 => 60,  90 => 32,  84 => 29,  76 => 28,  53 => 11,  498 => 160,  496 => 159,  490 => 156,  486 => 155,  475 => 153,  471 => 152,  464 => 151,  456 => 149,  451 => 146,  446 => 145,  433 => 140,  431 => 139,  425 => 136,  421 => 135,  410 => 133,  406 => 132,  395 => 130,  391 => 129,  386 => 126,  366 => 118,  364 => 117,  358 => 114,  354 => 113,  347 => 112,  343 => 111,  339 => 110,  332 => 109,  328 => 108,  324 => 107,  319 => 104,  300 => 97,  292 => 93,  288 => 92,  281 => 91,  266 => 88,  262 => 87,  253 => 83,  248 => 82,  233 => 76,  231 => 75,  225 => 72,  210 => 69,  195 => 66,  191 => 65,  186 => 62,  174 => 56,  152 => 51,  148 => 50,  137 => 48,  630 => 160,  617 => 157,  611 => 156,  605 => 155,  596 => 154,  590 => 153,  584 => 152,  575 => 151,  569 => 150,  563 => 149,  558 => 146,  553 => 145,  546 => 140,  533 => 137,  527 => 136,  521 => 135,  512 => 134,  506 => 133,  500 => 132,  491 => 131,  485 => 130,  479 => 154,  460 => 150,  447 => 115,  441 => 114,  426 => 112,  420 => 111,  414 => 134,  405 => 109,  399 => 131,  388 => 104,  383 => 103,  375 => 97,  356 => 93,  350 => 92,  335 => 90,  329 => 89,  320 => 88,  308 => 86,  303 => 83,  291 => 77,  277 => 90,  271 => 72,  265 => 71,  256 => 70,  250 => 69,  244 => 68,  223 => 65,  218 => 62,  213 => 61,  206 => 68,  181 => 61,  172 => 50,  160 => 48,  134 => 42,  129 => 41,  110 => 22,  65 => 21,  23 => 1,  480 => 162,  474 => 126,  469 => 125,  461 => 155,  457 => 153,  453 => 151,  444 => 149,  440 => 148,  437 => 147,  435 => 113,  430 => 144,  427 => 143,  423 => 142,  413 => 134,  409 => 132,  407 => 131,  402 => 130,  398 => 129,  393 => 107,  387 => 122,  384 => 121,  381 => 125,  379 => 119,  374 => 116,  368 => 112,  365 => 111,  362 => 94,  360 => 109,  355 => 106,  341 => 91,  337 => 103,  322 => 101,  314 => 103,  312 => 98,  309 => 97,  305 => 95,  298 => 96,  294 => 90,  285 => 89,  283 => 88,  278 => 86,  268 => 85,  264 => 84,  258 => 86,  252 => 80,  247 => 78,  241 => 77,  229 => 66,  220 => 70,  214 => 70,  177 => 65,  169 => 60,  140 => 55,  132 => 51,  128 => 44,  107 => 36,  61 => 12,  273 => 89,  269 => 94,  254 => 92,  243 => 88,  240 => 86,  238 => 85,  235 => 67,  230 => 82,  227 => 81,  224 => 71,  221 => 71,  219 => 76,  217 => 75,  208 => 68,  204 => 72,  179 => 69,  159 => 61,  143 => 56,  135 => 62,  119 => 41,  102 => 17,  71 => 24,  67 => 22,  63 => 19,  59 => 13,  201 => 92,  196 => 90,  183 => 82,  171 => 61,  166 => 55,  163 => 62,  158 => 79,  156 => 52,  151 => 47,  142 => 59,  138 => 54,  136 => 56,  121 => 46,  117 => 19,  105 => 18,  91 => 30,  62 => 22,  49 => 13,  94 => 34,  89 => 20,  85 => 32,  75 => 17,  68 => 23,  56 => 11,  87 => 28,  31 => 3,  28 => 3,  38 => 6,  26 => 9,  25 => 35,  21 => 2,  24 => 3,  19 => 1,  93 => 28,  88 => 31,  78 => 26,  46 => 8,  44 => 9,  27 => 4,  79 => 18,  72 => 22,  69 => 21,  47 => 8,  40 => 6,  37 => 5,  22 => 2,  246 => 90,  157 => 56,  145 => 46,  139 => 63,  131 => 61,  123 => 59,  120 => 20,  115 => 43,  111 => 37,  108 => 19,  101 => 43,  98 => 31,  96 => 31,  83 => 25,  74 => 27,  66 => 24,  55 => 15,  52 => 14,  50 => 10,  43 => 11,  41 => 10,  35 => 5,  32 => 1,  29 => 3,  209 => 82,  203 => 78,  199 => 67,  193 => 53,  189 => 71,  187 => 52,  182 => 66,  176 => 64,  173 => 65,  168 => 72,  164 => 54,  162 => 57,  154 => 58,  149 => 51,  147 => 58,  144 => 49,  141 => 49,  133 => 47,  130 => 41,  125 => 39,  122 => 43,  116 => 41,  112 => 42,  109 => 34,  106 => 45,  103 => 32,  99 => 31,  95 => 28,  92 => 28,  86 => 25,  82 => 28,  80 => 30,  73 => 16,  64 => 13,  60 => 21,  57 => 12,  54 => 10,  51 => 14,  48 => 9,  45 => 8,  42 => 7,  39 => 6,  36 => 5,  33 => 4,  30 => 3,);
    }
}
