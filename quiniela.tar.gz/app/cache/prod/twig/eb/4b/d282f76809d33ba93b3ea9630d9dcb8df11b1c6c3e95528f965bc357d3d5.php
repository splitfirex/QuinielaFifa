<?php

/* orgQuinielaBundle:Inicio:user.html.twig */
class __TwigTemplate_eb4bd282f76809d33ba93b3ea9630d9dcb8df11b1c6c3e95528f965bc357d3d5 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = $this->env->loadTemplate("orgQuinielaBundle::layout.html.twig");

        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'navbar' => array($this, 'block_navbar'),
            'content' => array($this, 'block_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "orgQuinielaBundle::layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    public function block_title($context, array $blocks = array())
    {
        echo "orgQuinielaBundle:Inicio:index";
    }

    // line 5
    public function block_navbar($context, array $blocks = array())
    {
        // line 6
        echo "<div id=\"menubar\">
\t<ul id=\"menu\">
\t\t<!-- put class=\"selected\" in the li tag for the selected page - to highlight which page you're on -->
\t\t<li class=\"selected\"><a href=\"";
        // line 9
        echo $this->env->getExtension('routing')->getPath("q_index");
        echo "\">Volver</a></li>
\t</ul>
</div>
";
    }

    // line 14
    public function block_content($context, array $blocks = array())
    {
        // line 15
        echo "
<div class=\"sidebar\">
\t<!-- insert your sidebar items here -->
\t<h3>Ranking</h3>
\t";
        // line 19
        $context["descending"] = 2;
        // line 20
        echo "\t";
        $context['_parent'] = (array) $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["usuarios"]) ? $context["usuarios"] : null));
        foreach ($context['_seq'] as $context["_key"] => $context["item"]) {
            if (($this->getAttribute((isset($context["item"]) ? $context["item"] : null), "id") != 999)) {
                // line 21
                echo "
\t";
                // line 22
                if (((isset($context["descending"]) ? $context["descending"] : null) > 1)) {
                    // line 23
                    echo "\t<h4 style=\"font-size:";
                    echo twig_escape_filter($this->env, (isset($context["descending"]) ? $context["descending"] : null), "html", null, true);
                    echo "em\"><a href=\"";
                    echo twig_escape_filter($this->env, $this->env->getExtension('routing')->getPath("q_user", array("id" => $this->getAttribute((isset($context["item"]) ? $context["item"] : null), "id"))), "html", null, true);
                    echo "\">";
                    echo twig_escape_filter($this->env, $this->getAttribute((isset($context["item"]) ? $context["item"] : null), "nombre"), "html", null, true);
                    echo " - ";
                    echo twig_escape_filter($this->env, $this->getAttribute((isset($context["item"]) ? $context["item"] : null), "puntos"), "html", null, true);
                    echo "</a></h4>\t

\t";
                    // line 25
                    $context["descending"] = ((isset($context["descending"]) ? $context["descending"] : null) - 0.2);
                    // line 26
                    echo "
\t";
                } else {
                    // line 28
                    echo "\t<h4 style=\"font-size:1em\"><a href=\"";
                    echo twig_escape_filter($this->env, $this->env->getExtension('routing')->getPath("q_user", array("id" => $this->getAttribute((isset($context["item"]) ? $context["item"] : null), "id"))), "html", null, true);
                    echo "\">";
                    echo twig_escape_filter($this->env, $this->getAttribute((isset($context["item"]) ? $context["item"] : null), "nombre"), "html", null, true);
                    echo " - ";
                    echo twig_escape_filter($this->env, $this->getAttribute((isset($context["item"]) ? $context["item"] : null), "puntos"), "html", null, true);
                    echo "</a></h4>\t
\t";
                }
                // line 30
                echo "
\t";
            }
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['item'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 32
        echo "

</div>
<div id=\"content\">
\t<!-- insert the page content here -->
\t<h1>";
        // line 37
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["usuario"]) ? $context["usuario"] : null), "nombre"), "html", null, true);
        echo " - ";
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["usuario"]) ? $context["usuario"] : null), "puntos"), "html", null, true);
        echo "</h1>
\t";
        // line 38
        $context["total"] = 0;
        // line 39
        echo "\t<h4>Fase Clasificación</h4>
\t<table style=\"width:100%;font-size:0.8em;\">
\t\t";
        // line 41
        $context['_parent'] = (array) $context;
        $context['_seq'] = twig_ensure_traversable($this->getAttribute((isset($context["usuario"]) ? $context["usuario"] : null), "partidos"));
        foreach ($context['_seq'] as $context["_key"] => $context["item"]) {
            if ((49 > $this->getAttribute((isset($context["item"]) ? $context["item"] : null), "numPartido"))) {
                // line 42
                echo "

\t\t<tr>
\t\t\t<td style=\"width:19px;background-color:";
                // line 45
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["item"]) ? $context["item"] : null), "color"), "html", null, true);
                echo ";\">";
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["item"]) ? $context["item"] : null), "numPartido"), "html", null, true);
                echo "</td>
\t\t\t<td style=\"text-align:right;width:180px;background-color:";
                // line 46
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["item"]) ? $context["item"] : null), "color"), "html", null, true);
                echo ";\">";
                echo twig_escape_filter($this->env, twig_date_format_filter($this->env, $this->getAttribute((isset($context["item"]) ? $context["item"] : null), "fecha"), " l j m/g/Y h:ia"), "html", null, true);
                echo "</td>
\t\t\t<td style=\"text-align:right;background-color:";
                // line 47
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["item"]) ? $context["item"] : null), "color"), "html", null, true);
                echo ";\">";
                echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["item"]) ? $context["item"] : null), "paisHome"), "nombre"), "html", null, true);
                echo " <img src=\"";
                echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("bundles/orgquiniela/images/flags/"), "html", null, true);
                echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["item"]) ? $context["item"] : null), "paisHome"), "bandera"), "html", null, true);
                echo "\"/></td>
\t\t\t<td style=\"text-align:center;width:20px;background-color:";
                // line 48
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["item"]) ? $context["item"] : null), "color"), "html", null, true);
                echo ";\">";
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["item"]) ? $context["item"] : null), "homeScore2"), "html", null, true);
                echo "</td>
\t\t\t<td style=\"text-align:center;width:20px;background-color:";
                // line 49
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["item"]) ? $context["item"] : null), "color"), "html", null, true);
                echo ";\">";
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["item"]) ? $context["item"] : null), "vistScore2"), "html", null, true);
                echo "</td> 
\t\t\t<td style=\"text-align:left;background-color:";
                // line 50
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["item"]) ? $context["item"] : null), "color"), "html", null, true);
                echo ";\"> <img src=\"";
                echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("bundles/orgquiniela/images/flags/"), "html", null, true);
                echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["item"]) ? $context["item"] : null), "paisVisitante"), "bandera"), "html", null, true);
                echo "\"/> ";
                echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["item"]) ? $context["item"] : null), "paisVisitante"), "nombre"), "html", null, true);
                echo "</td>
\t\t\t<td style=\"width:16px;text-align:center;background-color:";
                // line 51
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["item"]) ? $context["item"] : null), "color"), "html", null, true);
                echo ";\">";
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["item"]) ? $context["item"] : null), "RealHome"), "html", null, true);
                echo "</td>
\t\t\t<td style=\"width:16px;text-align:center;background-color:";
                // line 52
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["item"]) ? $context["item"] : null), "color"), "html", null, true);
                echo ";\">";
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["item"]) ? $context["item"] : null), "RealVisitante"), "html", null, true);
                echo "</td>
\t\t\t<td style=\"width:16px;text-align:center;background-color:";
                // line 53
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["item"]) ? $context["item"] : null), "color"), "html", null, true);
                echo ";\">";
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["item"]) ? $context["item"] : null), "puntaje"), "html", null, true);
                echo "</td>
\t\t</tr>

\t\t";
            }
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['item'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 56
        echo "\t\t
\t</table>

\t<h4>8vos de Final</h4>
\t<table style=\"width:100%;font-size:0.8em;\">
\t\t";
        // line 61
        $context['_parent'] = (array) $context;
        $context['_seq'] = twig_ensure_traversable($this->getAttribute((isset($context["usuario"]) ? $context["usuario"] : null), "partidos"));
        foreach ($context['_seq'] as $context["_key"] => $context["item"]) {
            if (((49 <= $this->getAttribute((isset($context["item"]) ? $context["item"] : null), "numPartido")) && ($this->getAttribute((isset($context["item"]) ? $context["item"] : null), "numPartido") < 57))) {
                // line 62
                echo "

\t\t<tr>
\t\t\t<td style=\"width:19px;background-color:";
                // line 65
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["item"]) ? $context["item"] : null), "color"), "html", null, true);
                echo ";\">";
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["item"]) ? $context["item"] : null), "numPartido"), "html", null, true);
                echo "</td>
\t\t\t<td style=\"text-align:right;width:180px;background-color:";
                // line 66
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["item"]) ? $context["item"] : null), "color"), "html", null, true);
                echo ";\">";
                echo twig_escape_filter($this->env, twig_date_format_filter($this->env, $this->getAttribute((isset($context["item"]) ? $context["item"] : null), "fecha"), " l j m/g/Y h:ia"), "html", null, true);
                echo "</td>
\t\t\t<td style=\"text-align:right;background-color:";
                // line 67
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["item"]) ? $context["item"] : null), "color"), "html", null, true);
                echo ";\">";
                echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["item"]) ? $context["item"] : null), "paisHome"), "nombre"), "html", null, true);
                echo " <img src=\"";
                echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("bundles/orgquiniela/images/flags/"), "html", null, true);
                echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["item"]) ? $context["item"] : null), "paisHome"), "bandera"), "html", null, true);
                echo "\"/></td>
\t\t\t<td style=\"text-align:center;width:20px;background-color:";
                // line 68
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["item"]) ? $context["item"] : null), "color"), "html", null, true);
                echo ";\">";
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["item"]) ? $context["item"] : null), "homeScore2"), "html", null, true);
                echo "</td>
\t\t\t<td style=\"text-align:center;width:20px;background-color:";
                // line 69
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["item"]) ? $context["item"] : null), "color"), "html", null, true);
                echo ";\">";
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["item"]) ? $context["item"] : null), "vistScore2"), "html", null, true);
                echo "</td> 
\t\t\t<td style=\"text-align:left;background-color:";
                // line 70
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["item"]) ? $context["item"] : null), "color"), "html", null, true);
                echo ";\"> <img src=\"";
                echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("bundles/orgquiniela/images/flags/"), "html", null, true);
                echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["item"]) ? $context["item"] : null), "paisVisitante"), "bandera"), "html", null, true);
                echo "\"/> ";
                echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["item"]) ? $context["item"] : null), "paisVisitante"), "nombre"), "html", null, true);
                echo "</td>
\t\t\t<td style=\"width:16px;text-align:center;background-color:";
                // line 71
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["item"]) ? $context["item"] : null), "color"), "html", null, true);
                echo ";\">";
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["item"]) ? $context["item"] : null), "RealHome"), "html", null, true);
                echo "</td>
\t\t\t<td style=\"width:16px;text-align:center;background-color:";
                // line 72
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["item"]) ? $context["item"] : null), "color"), "html", null, true);
                echo ";\">";
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["item"]) ? $context["item"] : null), "RealVisitante"), "html", null, true);
                echo "</td>
\t\t\t<td style=\"width:16px;text-align:center;background-color:";
                // line 73
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["item"]) ? $context["item"] : null), "color"), "html", null, true);
                echo ";\">";
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["item"]) ? $context["item"] : null), "puntaje"), "html", null, true);
                echo "</td>
\t\t</tr>


\t\t";
            }
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['item'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 77
        echo "\t\t
\t</table>

\t<h4>4tos de Final</h4>
\t<table style=\"width:100%;font-size:0.8em;\">
\t\t";
        // line 82
        $context['_parent'] = (array) $context;
        $context['_seq'] = twig_ensure_traversable($this->getAttribute((isset($context["usuario"]) ? $context["usuario"] : null), "partidos"));
        foreach ($context['_seq'] as $context["_key"] => $context["item"]) {
            if (((57 <= $this->getAttribute((isset($context["item"]) ? $context["item"] : null), "numPartido")) && ($this->getAttribute((isset($context["item"]) ? $context["item"] : null), "numPartido") < 61))) {
                // line 83
                echo "

\t\t<tr>
\t\t\t<td style=\"width:19px;background-color:";
                // line 86
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["item"]) ? $context["item"] : null), "color"), "html", null, true);
                echo ";\">";
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["item"]) ? $context["item"] : null), "numPartido"), "html", null, true);
                echo "</td>
\t\t\t<td style=\"text-align:right;width:180px;background-color:";
                // line 87
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["item"]) ? $context["item"] : null), "color"), "html", null, true);
                echo ";\">";
                echo twig_escape_filter($this->env, twig_date_format_filter($this->env, $this->getAttribute((isset($context["item"]) ? $context["item"] : null), "fecha"), " l j m/g/Y h:ia"), "html", null, true);
                echo "</td>
\t\t\t<td style=\"text-align:right;background-color:";
                // line 88
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["item"]) ? $context["item"] : null), "color"), "html", null, true);
                echo ";\">";
                echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["item"]) ? $context["item"] : null), "paisHome"), "nombre"), "html", null, true);
                echo " <img src=\"";
                echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("bundles/orgquiniela/images/flags/"), "html", null, true);
                echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["item"]) ? $context["item"] : null), "paisHome"), "bandera"), "html", null, true);
                echo "\"/></td>
\t\t\t<td style=\"text-align:center;width:20px;background-color:";
                // line 89
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["item"]) ? $context["item"] : null), "color"), "html", null, true);
                echo ";\">";
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["item"]) ? $context["item"] : null), "homeScore2"), "html", null, true);
                echo "</td>
\t\t\t<td style=\"text-align:center;width:20px;background-color:";
                // line 90
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["item"]) ? $context["item"] : null), "color"), "html", null, true);
                echo ";\">";
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["item"]) ? $context["item"] : null), "vistScore2"), "html", null, true);
                echo "</td> 
\t\t\t<td style=\"text-align:left;background-color:";
                // line 91
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["item"]) ? $context["item"] : null), "color"), "html", null, true);
                echo ";\"> <img src=\"";
                echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("bundles/orgquiniela/images/flags/"), "html", null, true);
                echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["item"]) ? $context["item"] : null), "paisVisitante"), "bandera"), "html", null, true);
                echo "\"/> ";
                echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["item"]) ? $context["item"] : null), "paisVisitante"), "nombre"), "html", null, true);
                echo "</td>
\t\t\t<td style=\"width:16px;text-align:center;background-color:";
                // line 92
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["item"]) ? $context["item"] : null), "color"), "html", null, true);
                echo ";\">";
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["item"]) ? $context["item"] : null), "RealHome"), "html", null, true);
                echo "</td>
\t\t\t<td style=\"width:16px;text-align:center;background-color:";
                // line 93
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["item"]) ? $context["item"] : null), "color"), "html", null, true);
                echo ";\">";
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["item"]) ? $context["item"] : null), "RealVisitante"), "html", null, true);
                echo "</td>
\t\t\t<td style=\"width:16px;text-align:center;background-color:";
                // line 94
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["item"]) ? $context["item"] : null), "color"), "html", null, true);
                echo ";\">";
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["item"]) ? $context["item"] : null), "puntaje"), "html", null, true);
                echo "</td>
\t\t</tr>

\t\t";
            }
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['item'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 97
        echo "\t\t
\t</table>


\t<h4>SemiFinal</h4>
\t<table style=\"width:100%;font-size:0.8em;\">
\t\t";
        // line 103
        $context['_parent'] = (array) $context;
        $context['_seq'] = twig_ensure_traversable($this->getAttribute((isset($context["usuario"]) ? $context["usuario"] : null), "partidos"));
        foreach ($context['_seq'] as $context["_key"] => $context["item"]) {
            if (((61 <= $this->getAttribute((isset($context["item"]) ? $context["item"] : null), "numPartido")) && ($this->getAttribute((isset($context["item"]) ? $context["item"] : null), "numPartido") < 63))) {
                // line 104
                echo "

\t\t<tr>
\t\t\t<td style=\"width:19px;background-color:";
                // line 107
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["item"]) ? $context["item"] : null), "color"), "html", null, true);
                echo ";\">";
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["item"]) ? $context["item"] : null), "numPartido"), "html", null, true);
                echo "</td>
\t\t\t<td style=\"text-align:right;width:180px;background-color:";
                // line 108
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["item"]) ? $context["item"] : null), "color"), "html", null, true);
                echo ";\">";
                echo twig_escape_filter($this->env, twig_date_format_filter($this->env, $this->getAttribute((isset($context["item"]) ? $context["item"] : null), "fecha"), " l j m/g/Y h:ia"), "html", null, true);
                echo "</td>
\t\t\t<td style=\"text-align:right;background-color:";
                // line 109
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["item"]) ? $context["item"] : null), "color"), "html", null, true);
                echo ";\">";
                echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["item"]) ? $context["item"] : null), "paisHome"), "nombre"), "html", null, true);
                echo " <img src=\"";
                echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("bundles/orgquiniela/images/flags/"), "html", null, true);
                echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["item"]) ? $context["item"] : null), "paisHome"), "bandera"), "html", null, true);
                echo "\"/></td>
\t\t\t<td style=\"text-align:center;width:20px;background-color:";
                // line 110
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["item"]) ? $context["item"] : null), "color"), "html", null, true);
                echo ";\">";
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["item"]) ? $context["item"] : null), "homeScore2"), "html", null, true);
                echo "</td>
\t\t\t<td style=\"text-align:center;width:20px;background-color:";
                // line 111
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["item"]) ? $context["item"] : null), "color"), "html", null, true);
                echo ";\">";
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["item"]) ? $context["item"] : null), "vistScore2"), "html", null, true);
                echo "</td> 
\t\t\t<td style=\"text-align:left;background-color:";
                // line 112
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["item"]) ? $context["item"] : null), "color"), "html", null, true);
                echo ";\"> <img src=\"";
                echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("bundles/orgquiniela/images/flags/"), "html", null, true);
                echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["item"]) ? $context["item"] : null), "paisVisitante"), "bandera"), "html", null, true);
                echo "\"/> ";
                echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["item"]) ? $context["item"] : null), "paisVisitante"), "nombre"), "html", null, true);
                echo "</td>
\t\t\t<td style=\"width:16px;text-align:center;background-color:";
                // line 113
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["item"]) ? $context["item"] : null), "color"), "html", null, true);
                echo ";\">";
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["item"]) ? $context["item"] : null), "RealHome"), "html", null, true);
                echo "</td>
\t\t\t<td style=\"width:16px;text-align:center;background-color:";
                // line 114
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["item"]) ? $context["item"] : null), "color"), "html", null, true);
                echo ";\">";
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["item"]) ? $context["item"] : null), "RealVisitante"), "html", null, true);
                echo "</td>
\t\t\t<td style=\"width:16px;text-align:center;background-color:";
                // line 115
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["item"]) ? $context["item"] : null), "color"), "html", null, true);
                echo ";\">";
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["item"]) ? $context["item"] : null), "puntaje"), "html", null, true);
                echo "</td>
\t\t</tr>

\t\t";
            }
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['item'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 118
        echo "\t\t
\t</table>



\t<h4>Tercer Lugar</h4>
\t<table style=\"width:100%;font-size:0.8em;\">
\t\t";
        // line 125
        $context['_parent'] = (array) $context;
        $context['_seq'] = twig_ensure_traversable($this->getAttribute((isset($context["usuario"]) ? $context["usuario"] : null), "partidos"));
        foreach ($context['_seq'] as $context["_key"] => $context["item"]) {
            if (((63 <= $this->getAttribute((isset($context["item"]) ? $context["item"] : null), "numPartido")) && ($this->getAttribute((isset($context["item"]) ? $context["item"] : null), "numPartido") < 64))) {
                // line 126
                echo "

\t\t<tr>
\t\t\t<td style=\"width:19px;background-color:";
                // line 129
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["item"]) ? $context["item"] : null), "color"), "html", null, true);
                echo ";\">";
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["item"]) ? $context["item"] : null), "numPartido"), "html", null, true);
                echo "</td>
\t\t\t<td style=\"text-align:right;width:180px;background-color:";
                // line 130
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["item"]) ? $context["item"] : null), "color"), "html", null, true);
                echo ";\">";
                echo twig_escape_filter($this->env, twig_date_format_filter($this->env, $this->getAttribute((isset($context["item"]) ? $context["item"] : null), "fecha"), " l j m/g/Y h:ia"), "html", null, true);
                echo "</td>
\t\t\t<td style=\"text-align:right;background-color:";
                // line 131
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["item"]) ? $context["item"] : null), "color"), "html", null, true);
                echo ";\">";
                echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["item"]) ? $context["item"] : null), "paisHome"), "nombre"), "html", null, true);
                echo " <img src=\"";
                echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("bundles/orgquiniela/images/flags/"), "html", null, true);
                echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["item"]) ? $context["item"] : null), "paisHome"), "bandera"), "html", null, true);
                echo "\"/></td>
\t\t\t<td style=\"text-align:center;width:20px;background-color:";
                // line 132
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["item"]) ? $context["item"] : null), "color"), "html", null, true);
                echo ";\">";
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["item"]) ? $context["item"] : null), "homeScore2"), "html", null, true);
                echo "</td>
\t\t\t<td style=\"text-align:center;width:20px;background-color:";
                // line 133
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["item"]) ? $context["item"] : null), "color"), "html", null, true);
                echo ";\">";
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["item"]) ? $context["item"] : null), "vistScore2"), "html", null, true);
                echo "</td> 
\t\t\t<td style=\"text-align:left;background-color:";
                // line 134
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["item"]) ? $context["item"] : null), "color"), "html", null, true);
                echo ";\"> <img src=\"";
                echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("bundles/orgquiniela/images/flags/"), "html", null, true);
                echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["item"]) ? $context["item"] : null), "paisVisitante"), "bandera"), "html", null, true);
                echo "\"/> ";
                echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["item"]) ? $context["item"] : null), "paisVisitante"), "nombre"), "html", null, true);
                echo "</td>
\t\t\t<td style=\"width:16px;text-align:center;background-color:";
                // line 135
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["item"]) ? $context["item"] : null), "color"), "html", null, true);
                echo ";\">";
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["item"]) ? $context["item"] : null), "RealHome"), "html", null, true);
                echo "</td>
\t\t\t<td style=\"width:16px;text-align:center;background-color:";
                // line 136
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["item"]) ? $context["item"] : null), "color"), "html", null, true);
                echo ";\">";
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["item"]) ? $context["item"] : null), "RealVisitante"), "html", null, true);
                echo "</td>
\t\t\t<td style=\"width:16px;text-align:center;background-color:";
                // line 137
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["item"]) ? $context["item"] : null), "color"), "html", null, true);
                echo ";\">";
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["item"]) ? $context["item"] : null), "puntaje"), "html", null, true);
                echo "</td>
\t\t</tr>

\t\t";
            }
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['item'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 140
        echo "\t\t
\t</table>

\t<h4>Final</h4>
\t<table style=\"width:100%;font-size:0.8em;\">
\t\t";
        // line 145
        $context['_parent'] = (array) $context;
        $context['_seq'] = twig_ensure_traversable($this->getAttribute((isset($context["usuario"]) ? $context["usuario"] : null), "partidos"));
        foreach ($context['_seq'] as $context["_key"] => $context["item"]) {
            if (((64 <= $this->getAttribute((isset($context["item"]) ? $context["item"] : null), "numPartido")) && ($this->getAttribute((isset($context["item"]) ? $context["item"] : null), "numPartido") < 65))) {
                // line 146
                echo "

\t\t<tr>
\t\t\t<td style=\"width:19px;background-color:";
                // line 149
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["item"]) ? $context["item"] : null), "color"), "html", null, true);
                echo ";\">";
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["item"]) ? $context["item"] : null), "numPartido"), "html", null, true);
                echo "</td>
\t\t\t<td style=\"text-align:right;width:180px;background-color:";
                // line 150
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["item"]) ? $context["item"] : null), "color"), "html", null, true);
                echo ";\">";
                echo twig_escape_filter($this->env, twig_date_format_filter($this->env, $this->getAttribute((isset($context["item"]) ? $context["item"] : null), "fecha"), " l j m/g/Y h:ia"), "html", null, true);
                echo "</td>
\t\t\t<td style=\"text-align:right;background-color:";
                // line 151
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["item"]) ? $context["item"] : null), "color"), "html", null, true);
                echo ";\">";
                echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["item"]) ? $context["item"] : null), "paisHome"), "nombre"), "html", null, true);
                echo " <img src=\"";
                echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("bundles/orgquiniela/images/flags/"), "html", null, true);
                echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["item"]) ? $context["item"] : null), "paisHome"), "bandera"), "html", null, true);
                echo "\"/></td>
\t\t\t<td style=\"text-align:center;width:20px;background-color:";
                // line 152
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["item"]) ? $context["item"] : null), "color"), "html", null, true);
                echo ";\">";
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["item"]) ? $context["item"] : null), "homeScore2"), "html", null, true);
                echo "</td>
\t\t\t<td style=\"text-align:center;width:20px;background-color:";
                // line 153
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["item"]) ? $context["item"] : null), "color"), "html", null, true);
                echo ";\">";
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["item"]) ? $context["item"] : null), "vistScore2"), "html", null, true);
                echo "</td> 
\t\t\t<td style=\"text-align:left;background-color:";
                // line 154
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["item"]) ? $context["item"] : null), "color"), "html", null, true);
                echo ";\"> <img src=\"";
                echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("bundles/orgquiniela/images/flags/"), "html", null, true);
                echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["item"]) ? $context["item"] : null), "paisVisitante"), "bandera"), "html", null, true);
                echo "\"/> ";
                echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["item"]) ? $context["item"] : null), "paisVisitante"), "nombre"), "html", null, true);
                echo "</td>
\t\t\t<td style=\"width:16px;text-align:center;background-color:";
                // line 155
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["item"]) ? $context["item"] : null), "color"), "html", null, true);
                echo ";\">";
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["item"]) ? $context["item"] : null), "RealHome"), "html", null, true);
                echo "</td>
\t\t\t<td style=\"width:16px;text-align:center;background-color:";
                // line 156
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["item"]) ? $context["item"] : null), "color"), "html", null, true);
                echo ";\">";
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["item"]) ? $context["item"] : null), "RealVisitante"), "html", null, true);
                echo "</td>
\t\t\t<td style=\"width:16px;text-align:center;background-color:";
                // line 157
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["item"]) ? $context["item"] : null), "color"), "html", null, true);
                echo ";\">";
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["item"]) ? $context["item"] : null), "puntaje"), "html", null, true);
                echo "</td>
\t\t</tr>

\t\t";
            }
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['item'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 160
        echo "\t\t
\t</table>

</div>
</div>
<div id=\"content_footer\"></div>
<div id=\"footer\">
</div>


";
    }

    public function getTemplateName()
    {
        return "orgQuinielaBundle:Inicio:user.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  630 => 160,  617 => 157,  611 => 156,  605 => 155,  596 => 154,  590 => 153,  584 => 152,  575 => 151,  569 => 150,  563 => 149,  558 => 146,  553 => 145,  546 => 140,  533 => 137,  527 => 136,  521 => 135,  512 => 134,  506 => 133,  500 => 132,  491 => 131,  485 => 130,  479 => 129,  460 => 118,  447 => 115,  441 => 114,  426 => 112,  420 => 111,  414 => 110,  405 => 109,  399 => 108,  388 => 104,  383 => 103,  375 => 97,  356 => 93,  350 => 92,  335 => 90,  329 => 89,  320 => 88,  308 => 86,  303 => 83,  291 => 77,  277 => 73,  271 => 72,  265 => 71,  256 => 70,  250 => 69,  244 => 68,  223 => 65,  218 => 62,  213 => 61,  206 => 56,  181 => 51,  172 => 50,  160 => 48,  145 => 46,  139 => 45,  134 => 42,  129 => 41,  110 => 32,  74 => 23,  52 => 14,  65 => 21,  23 => 1,  480 => 162,  474 => 126,  469 => 125,  461 => 155,  457 => 153,  453 => 151,  444 => 149,  440 => 148,  437 => 147,  435 => 113,  430 => 144,  427 => 143,  423 => 142,  413 => 134,  409 => 132,  407 => 131,  402 => 130,  398 => 129,  393 => 107,  387 => 122,  384 => 121,  381 => 120,  379 => 119,  374 => 116,  368 => 112,  365 => 111,  362 => 94,  360 => 109,  355 => 106,  341 => 91,  337 => 103,  322 => 101,  314 => 87,  312 => 98,  309 => 97,  305 => 95,  298 => 82,  294 => 90,  285 => 89,  283 => 88,  278 => 86,  268 => 85,  264 => 84,  258 => 81,  252 => 80,  247 => 78,  241 => 77,  229 => 66,  220 => 70,  214 => 69,  177 => 65,  169 => 60,  140 => 55,  132 => 51,  128 => 49,  111 => 37,  107 => 36,  61 => 19,  273 => 96,  269 => 94,  254 => 92,  246 => 90,  243 => 88,  240 => 86,  238 => 85,  235 => 67,  230 => 82,  227 => 81,  224 => 71,  221 => 77,  219 => 76,  217 => 75,  208 => 68,  204 => 72,  179 => 69,  159 => 61,  143 => 56,  135 => 53,  131 => 52,  119 => 42,  108 => 36,  102 => 30,  71 => 17,  67 => 22,  63 => 20,  59 => 14,  47 => 9,  201 => 92,  196 => 90,  183 => 82,  171 => 61,  166 => 49,  163 => 62,  158 => 67,  156 => 66,  151 => 47,  142 => 59,  138 => 54,  136 => 56,  123 => 38,  121 => 46,  117 => 37,  115 => 43,  105 => 40,  91 => 27,  69 => 21,  62 => 23,  49 => 19,  101 => 32,  94 => 28,  89 => 20,  85 => 25,  79 => 18,  75 => 17,  68 => 14,  56 => 9,  50 => 10,  87 => 25,  72 => 22,  66 => 24,  55 => 15,  31 => 5,  41 => 7,  28 => 5,  43 => 6,  35 => 2,  29 => 3,  38 => 6,  26 => 6,  25 => 4,  21 => 2,  24 => 3,  19 => 1,  98 => 31,  93 => 28,  88 => 26,  78 => 21,  46 => 7,  44 => 9,  40 => 7,  32 => 1,  27 => 4,  22 => 2,  209 => 82,  203 => 78,  199 => 67,  193 => 53,  189 => 71,  187 => 52,  182 => 66,  176 => 64,  173 => 65,  168 => 72,  164 => 59,  162 => 59,  154 => 58,  149 => 51,  147 => 58,  144 => 49,  141 => 48,  133 => 55,  130 => 41,  125 => 39,  122 => 43,  116 => 41,  112 => 42,  109 => 34,  106 => 33,  103 => 32,  99 => 31,  95 => 28,  92 => 28,  86 => 25,  82 => 22,  80 => 19,  73 => 14,  64 => 14,  60 => 13,  57 => 15,  54 => 10,  51 => 14,  48 => 8,  45 => 6,  42 => 5,  39 => 6,  36 => 5,  33 => 4,  30 => 3,);
    }
}
