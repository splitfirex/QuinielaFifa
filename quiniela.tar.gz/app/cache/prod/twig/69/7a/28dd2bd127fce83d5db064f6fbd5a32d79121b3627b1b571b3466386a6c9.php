<?php

/* orgQuinielaBundle:Inicio:index.html.twig */
class __TwigTemplate_697a28dd2bd127fce83d5db064f6fbd5a32d79121b3627b1b571b3466386a6c9 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = $this->env->loadTemplate("orgQuinielaBundle::layout.html.twig");

        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'navbar' => array($this, 'block_navbar'),
            'content' => array($this, 'block_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "orgQuinielaBundle::layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    public function block_title($context, array $blocks = array())
    {
        echo "orgQuinielaBundle:Inicio:index";
    }

    // line 5
    public function block_navbar($context, array $blocks = array())
    {
        // line 6
        echo "<div id=\"menubar\">
      <ul id=\"menu\">
        <!-- put class=\"selected\" in the li tag for the selected page - to highlight which page you're on -->
        <li class=\"selected\"><a href=\"#\">Bienvenido</a></li>
      </ul>
    </div>
";
    }

    // line 14
    public function block_content($context, array $blocks = array())
    {
        // line 15
        echo "
<div class=\"sidebar\">
\t<!-- insert your sidebar items here -->
\t<h3>Ranking</h3>


\t";
        // line 21
        $context["descending"] = 2;
        // line 22
        echo "\t";
        $context['_parent'] = (array) $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["usuarios"]) ? $context["usuarios"] : null));
        foreach ($context['_seq'] as $context["_key"] => $context["item"]) {
            if (($this->getAttribute((isset($context["item"]) ? $context["item"] : null), "id") != 999)) {
                // line 23
                echo "
\t\t";
                // line 24
                if (((isset($context["descending"]) ? $context["descending"] : null) > 1)) {
                    // line 25
                    echo "    \t<h4 style=\"font-size:";
                    echo twig_escape_filter($this->env, (isset($context["descending"]) ? $context["descending"] : null), "html", null, true);
                    echo "em\"><a href=\"";
                    echo twig_escape_filter($this->env, $this->env->getExtension('routing')->getPath("q_user", array("id" => $this->getAttribute((isset($context["item"]) ? $context["item"] : null), "id"))), "html", null, true);
                    echo "\">";
                    echo twig_escape_filter($this->env, $this->getAttribute((isset($context["item"]) ? $context["item"] : null), "nombre"), "html", null, true);
                    echo " - ";
                    echo twig_escape_filter($this->env, $this->getAttribute((isset($context["item"]) ? $context["item"] : null), "puntos"), "html", null, true);
                    echo "</a></h4>\t

\t\t";
                    // line 27
                    $context["descending"] = ((isset($context["descending"]) ? $context["descending"] : null) - 0.2);
                    // line 28
                    echo "
    \t";
                } else {
                    // line 30
                    echo "\t\t<h4 style=\"font-size:1em\"><a href=\"";
                    echo twig_escape_filter($this->env, $this->env->getExtension('routing')->getPath("q_user", array("id" => $this->getAttribute((isset($context["item"]) ? $context["item"] : null), "id"))), "html", null, true);
                    echo "\">";
                    echo twig_escape_filter($this->env, $this->getAttribute((isset($context["item"]) ? $context["item"] : null), "nombre"), "html", null, true);
                    echo " - ";
                    echo twig_escape_filter($this->env, $this->getAttribute((isset($context["item"]) ? $context["item"] : null), "puntos"), "html", null, true);
                    echo "</a></h4>\t
\t\t";
                }
                // line 32
                echo "
    ";
            }
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['item'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 34
        echo "

</div>
<div id=\"content\">
\t<!-- insert the page content here -->
\t\t<h2>Resultados de partidos</h2>
\t";
        // line 40
        $context["total"] = 0;
        // line 41
        echo "\t<h4>Fase Clasificación</h4>
\t<table style=\"width:100%;font-size:0.8em;\">
\t\t";
        // line 43
        $context['_parent'] = (array) $context;
        $context['_seq'] = twig_ensure_traversable($this->getAttribute((isset($context["usuario"]) ? $context["usuario"] : null), "partidos"));
        foreach ($context['_seq'] as $context["_key"] => $context["item"]) {
            if ((49 > $this->getAttribute((isset($context["item"]) ? $context["item"] : null), "numPartido"))) {
                // line 44
                echo "

\t\t<tr>
\t\t\t<td  style=\"width:19px\">";
                // line 47
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["item"]) ? $context["item"] : null), "numPartido"), "html", null, true);
                echo "</td>
<td style=\"text-align:right;width:180px\">";
                // line 48
                echo twig_escape_filter($this->env, twig_date_format_filter($this->env, $this->getAttribute((isset($context["item"]) ? $context["item"] : null), "fecha"), " l j m/g/Y h:ia"), "html", null, true);
                echo "</td>
\t\t\t<td style=\"text-align:right\">";
                // line 49
                echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["item"]) ? $context["item"] : null), "paisHome"), "nombre"), "html", null, true);
                echo " <img src=\"";
                echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("bundles/orgquiniela/images/flags/"), "html", null, true);
                echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["item"]) ? $context["item"] : null), "paisHome"), "bandera"), "html", null, true);
                echo "\"/></td>
\t\t\t<td style=\"text-align:center;width:20px\">";
                // line 50
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["item"]) ? $context["item"] : null), "homeScore"), "html", null, true);
                echo "</td>
\t\t\t<td style=\"text-align:center;width:20px\">";
                // line 51
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["item"]) ? $context["item"] : null), "vistScore"), "html", null, true);
                echo "</td> 
\t\t\t<td style=\"text-align:left;width:150px\"> <img src=\"";
                // line 52
                echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("bundles/orgquiniela/images/flags/"), "html", null, true);
                echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["item"]) ? $context["item"] : null), "paisVisitante"), "bandera"), "html", null, true);
                echo "\"/> ";
                echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["item"]) ? $context["item"] : null), "paisVisitante"), "nombre"), "html", null, true);
                echo "</td>
\t\t</tr>
\t\t";
                // line 54
                $context["total"] = ((isset($context["total"]) ? $context["total"] : null) + $this->getAttribute((isset($context["item"]) ? $context["item"] : null), "puntaje"));
                // line 55
                echo "
\t\t";
            }
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['item'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 56
        echo "\t\t
\t</table>

\t<h4>8vos de Final</h4>
\t<table style=\"width:100%;font-size:0.8em;\">
\t\t";
        // line 61
        $context['_parent'] = (array) $context;
        $context['_seq'] = twig_ensure_traversable($this->getAttribute((isset($context["usuario"]) ? $context["usuario"] : null), "partidos"));
        foreach ($context['_seq'] as $context["_key"] => $context["item"]) {
            if (((49 <= $this->getAttribute((isset($context["item"]) ? $context["item"] : null), "numPartido")) && ($this->getAttribute((isset($context["item"]) ? $context["item"] : null), "numPartido") < 57))) {
                // line 62
                echo "

\t\t<tr>
\t\t\t<td  style=\"width:19px\">";
                // line 65
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["item"]) ? $context["item"] : null), "numPartido"), "html", null, true);
                echo "</td>
<td style=\"text-align:right;width:180px\">";
                // line 66
                echo twig_escape_filter($this->env, twig_date_format_filter($this->env, $this->getAttribute((isset($context["item"]) ? $context["item"] : null), "fecha"), " l j m/g/Y h:ia"), "html", null, true);
                echo "</td>
\t\t\t<td style=\"text-align:right\">";
                // line 67
                echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["item"]) ? $context["item"] : null), "paisHome"), "nombre"), "html", null, true);
                echo " <img src=\"";
                echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("bundles/orgquiniela/images/flags/"), "html", null, true);
                echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["item"]) ? $context["item"] : null), "paisHome"), "bandera"), "html", null, true);
                echo "\"/></td>
\t\t\t<td style=\"text-align:center;width:20px\">";
                // line 68
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["item"]) ? $context["item"] : null), "homeScore"), "html", null, true);
                echo "</td>
\t\t\t<td style=\"text-align:center;width:20px\">";
                // line 69
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["item"]) ? $context["item"] : null), "vistScore"), "html", null, true);
                echo "</td> 
\t\t\t<td style=\"text-align:left;width:150px\"> <img src=\"";
                // line 70
                echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("bundles/orgquiniela/images/flags/"), "html", null, true);
                echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["item"]) ? $context["item"] : null), "paisVisitante"), "bandera"), "html", null, true);
                echo "\"/> ";
                echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["item"]) ? $context["item"] : null), "paisVisitante"), "nombre"), "html", null, true);
                echo "</td>
\t\t\t<td style=\"width:16px;text-align:center\">";
                // line 71
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["item"]) ? $context["item"] : null), "homePenal"), "html", null, true);
                echo "</td>
\t\t\t<td style=\"width:16px;text-align:center\">";
                // line 72
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["item"]) ? $context["item"] : null), "vistPenal"), "html", null, true);
                echo "</td>
\t\t</tr>

\t\t";
                // line 75
                $context["total"] = ((isset($context["total"]) ? $context["total"] : null) + $this->getAttribute((isset($context["item"]) ? $context["item"] : null), "puntaje"));
                // line 76
                echo "
\t\t";
            }
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['item'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 77
        echo "\t\t
\t</table>

\t<h4>4tos de Final</h4>
\t<table style=\"width:100%;font-size:0.8em;\">
\t\t";
        // line 82
        $context['_parent'] = (array) $context;
        $context['_seq'] = twig_ensure_traversable($this->getAttribute((isset($context["usuario"]) ? $context["usuario"] : null), "partidos"));
        foreach ($context['_seq'] as $context["_key"] => $context["item"]) {
            if (((57 <= $this->getAttribute((isset($context["item"]) ? $context["item"] : null), "numPartido")) && ($this->getAttribute((isset($context["item"]) ? $context["item"] : null), "numPartido") < 61))) {
                // line 83
                echo "

\t\t<tr>
\t\t\t<td  style=\"width:19px\">";
                // line 86
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["item"]) ? $context["item"] : null), "numPartido"), "html", null, true);
                echo "</td>
<td style=\"text-align:right;width:180px\">";
                // line 87
                echo twig_escape_filter($this->env, twig_date_format_filter($this->env, $this->getAttribute((isset($context["item"]) ? $context["item"] : null), "fecha"), " l j m/g/Y h:ia"), "html", null, true);
                echo "</td>
\t\t\t<td style=\"text-align:right\">";
                // line 88
                echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["item"]) ? $context["item"] : null), "paisHome"), "nombre"), "html", null, true);
                echo " <img src=\"";
                echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("bundles/orgquiniela/images/flags/"), "html", null, true);
                echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["item"]) ? $context["item"] : null), "paisHome"), "bandera"), "html", null, true);
                echo "\"/></td>
\t\t\t<td style=\"text-align:center;width:20px\">";
                // line 89
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["item"]) ? $context["item"] : null), "homeScore"), "html", null, true);
                echo "</td>
\t\t\t<td style=\"text-align:center;width:20px\">";
                // line 90
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["item"]) ? $context["item"] : null), "vistScore"), "html", null, true);
                echo "</td> 
\t\t\t<td style=\"text-align:left;width:150px\"> <img src=\"";
                // line 91
                echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("bundles/orgquiniela/images/flags/"), "html", null, true);
                echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["item"]) ? $context["item"] : null), "paisVisitante"), "bandera"), "html", null, true);
                echo "\"/> ";
                echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["item"]) ? $context["item"] : null), "paisVisitante"), "nombre"), "html", null, true);
                echo "</td>
\t\t\t<td style=\"width:16px;text-align:center\">";
                // line 92
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["item"]) ? $context["item"] : null), "homePenal"), "html", null, true);
                echo "</td>
\t\t\t<td style=\"width:16px;text-align:center\">";
                // line 93
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["item"]) ? $context["item"] : null), "vistPenal"), "html", null, true);
                echo "</td>
\t\t</tr>

\t\t";
                // line 96
                $context["total"] = ((isset($context["total"]) ? $context["total"] : null) + $this->getAttribute((isset($context["item"]) ? $context["item"] : null), "puntaje"));
                // line 97
                echo "\t\t";
            }
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['item'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        echo "\t\t
\t</table>


\t<h4>SemiFinal</h4>
\t<table style=\"width:100%;font-size:0.8em;\">
\t\t";
        // line 103
        $context['_parent'] = (array) $context;
        $context['_seq'] = twig_ensure_traversable($this->getAttribute((isset($context["usuario"]) ? $context["usuario"] : null), "partidos"));
        foreach ($context['_seq'] as $context["_key"] => $context["item"]) {
            if (((61 <= $this->getAttribute((isset($context["item"]) ? $context["item"] : null), "numPartido")) && ($this->getAttribute((isset($context["item"]) ? $context["item"] : null), "numPartido") < 63))) {
                // line 104
                echo "

\t\t<tr>
\t\t\t<td  style=\"width:19px\">";
                // line 107
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["item"]) ? $context["item"] : null), "numPartido"), "html", null, true);
                echo "</td>
<td style=\"text-align:right;width:180px\">";
                // line 108
                echo twig_escape_filter($this->env, twig_date_format_filter($this->env, $this->getAttribute((isset($context["item"]) ? $context["item"] : null), "fecha"), " l j m/g/Y h:ia"), "html", null, true);
                echo "</td>
\t\t\t<td style=\"text-align:right\">";
                // line 109
                echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["item"]) ? $context["item"] : null), "paisHome"), "nombre"), "html", null, true);
                echo " <img src=\"";
                echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("bundles/orgquiniela/images/flags/"), "html", null, true);
                echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["item"]) ? $context["item"] : null), "paisHome"), "bandera"), "html", null, true);
                echo "\"/></td>
\t\t\t<td style=\"text-align:center;width:20px\">";
                // line 110
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["item"]) ? $context["item"] : null), "homeScore"), "html", null, true);
                echo "</td>
\t\t\t<td style=\"text-align:center;width:20px\">";
                // line 111
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["item"]) ? $context["item"] : null), "vistScore"), "html", null, true);
                echo "</td> 
\t\t\t<td style=\"text-align:left;width:150px\"> <img src=\"";
                // line 112
                echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("bundles/orgquiniela/images/flags/"), "html", null, true);
                echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["item"]) ? $context["item"] : null), "paisVisitante"), "bandera"), "html", null, true);
                echo "\"/> ";
                echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["item"]) ? $context["item"] : null), "paisVisitante"), "nombre"), "html", null, true);
                echo "</td>
\t\t\t<td style=\"width:16px;text-align:center\">";
                // line 113
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["item"]) ? $context["item"] : null), "homePenal"), "html", null, true);
                echo "</td>
\t\t\t<td style=\"width:16px;text-align:center\">";
                // line 114
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["item"]) ? $context["item"] : null), "vistPenal"), "html", null, true);
                echo "</td>
\t\t</tr>

\t\t";
                // line 117
                $context["total"] = ((isset($context["total"]) ? $context["total"] : null) + $this->getAttribute((isset($context["item"]) ? $context["item"] : null), "puntaje"));
                // line 118
                echo "\t\t";
            }
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['item'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        echo "\t\t
\t</table>



\t<h4>Tercer Lugar</h4>
\t<table style=\"width:100%;font-size:0.8em;\">
\t\t";
        // line 125
        $context['_parent'] = (array) $context;
        $context['_seq'] = twig_ensure_traversable($this->getAttribute((isset($context["usuario"]) ? $context["usuario"] : null), "partidos"));
        foreach ($context['_seq'] as $context["_key"] => $context["item"]) {
            if (((63 <= $this->getAttribute((isset($context["item"]) ? $context["item"] : null), "numPartido")) && ($this->getAttribute((isset($context["item"]) ? $context["item"] : null), "numPartido") < 64))) {
                // line 126
                echo "

\t\t<tr>
\t\t\t<td  style=\"width:19px\">";
                // line 129
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["item"]) ? $context["item"] : null), "numPartido"), "html", null, true);
                echo "</td>
<td style=\"text-align:right;width:180px\">";
                // line 130
                echo twig_escape_filter($this->env, twig_date_format_filter($this->env, $this->getAttribute((isset($context["item"]) ? $context["item"] : null), "fecha"), " l j m/g/Y h:ia"), "html", null, true);
                echo "</td>
\t\t\t<td style=\"text-align:right\">";
                // line 131
                echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["item"]) ? $context["item"] : null), "paisHome"), "nombre"), "html", null, true);
                echo " <img src=\"";
                echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("bundles/orgquiniela/images/flags/"), "html", null, true);
                echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["item"]) ? $context["item"] : null), "paisHome"), "bandera"), "html", null, true);
                echo "\"/></td>
\t\t\t<td style=\"text-align:center;width:20px\">";
                // line 132
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["item"]) ? $context["item"] : null), "homeScore"), "html", null, true);
                echo "</td>
\t\t\t<td style=\"text-align:center;width:20px\">";
                // line 133
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["item"]) ? $context["item"] : null), "vistScore"), "html", null, true);
                echo "</td> 
\t\t\t<td style=\"text-align:left;width:150px\"> <img src=\"";
                // line 134
                echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("bundles/orgquiniela/images/flags/"), "html", null, true);
                echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["item"]) ? $context["item"] : null), "paisVisitante"), "bandera"), "html", null, true);
                echo "\"/> ";
                echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["item"]) ? $context["item"] : null), "paisVisitante"), "nombre"), "html", null, true);
                echo "</td>
\t\t\t<td style=\"width:16px;text-align:center\">";
                // line 135
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["item"]) ? $context["item"] : null), "homePenal"), "html", null, true);
                echo "</td>
\t\t\t<td style=\"width:16px;text-align:center\">";
                // line 136
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["item"]) ? $context["item"] : null), "vistPenal"), "html", null, true);
                echo "</td>
\t\t</tr>

\t\t";
                // line 139
                $context["total"] = ((isset($context["total"]) ? $context["total"] : null) + $this->getAttribute((isset($context["item"]) ? $context["item"] : null), "puntaje"));
                // line 140
                echo "\t\t";
            }
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['item'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        echo "\t\t
\t</table>

\t<h4>Final</h4>
\t<table style=\"width:100%;font-size:0.8em;\">
\t\t";
        // line 145
        $context['_parent'] = (array) $context;
        $context['_seq'] = twig_ensure_traversable($this->getAttribute((isset($context["usuario"]) ? $context["usuario"] : null), "partidos"));
        foreach ($context['_seq'] as $context["_key"] => $context["item"]) {
            if (((64 <= $this->getAttribute((isset($context["item"]) ? $context["item"] : null), "numPartido")) && ($this->getAttribute((isset($context["item"]) ? $context["item"] : null), "numPartido") < 65))) {
                // line 146
                echo "

\t\t<tr>
\t\t\t<td  style=\"width:19px\">";
                // line 149
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["item"]) ? $context["item"] : null), "numPartido"), "html", null, true);
                echo "</td>
<td style=\"text-align:right;width:180px\">";
                // line 150
                echo twig_escape_filter($this->env, twig_date_format_filter($this->env, $this->getAttribute((isset($context["item"]) ? $context["item"] : null), "fecha"), " l j m/g/Y h:ia"), "html", null, true);
                echo "</td>
\t\t\t<td style=\"text-align:right\">";
                // line 151
                echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["item"]) ? $context["item"] : null), "paisHome"), "nombre"), "html", null, true);
                echo " <img src=\"";
                echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("bundles/orgquiniela/images/flags/"), "html", null, true);
                echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["item"]) ? $context["item"] : null), "paisHome"), "bandera"), "html", null, true);
                echo "\"/></td>
\t\t\t<td style=\"text-align:center;width:20px\">";
                // line 152
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["item"]) ? $context["item"] : null), "homeScore"), "html", null, true);
                echo "</td>
\t\t\t<td style=\"text-align:center;width:20px\">";
                // line 153
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["item"]) ? $context["item"] : null), "vistScore"), "html", null, true);
                echo "</td> 
\t\t\t<td style=\"text-align:left;width:150px\"> <img src=\"";
                // line 154
                echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("bundles/orgquiniela/images/flags/"), "html", null, true);
                echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["item"]) ? $context["item"] : null), "paisVisitante"), "bandera"), "html", null, true);
                echo "\"/> ";
                echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["item"]) ? $context["item"] : null), "paisVisitante"), "nombre"), "html", null, true);
                echo "</td>
\t\t\t<td style=\"width:16px;text-align:center\">";
                // line 155
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["item"]) ? $context["item"] : null), "homePenal"), "html", null, true);
                echo "</td>
\t\t\t<td style=\"width:16px;text-align:center\">";
                // line 156
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["item"]) ? $context["item"] : null), "vistPenal"), "html", null, true);
                echo "</td>
\t\t</tr>

\t\t";
                // line 159
                $context["total"] = ((isset($context["total"]) ? $context["total"] : null) + $this->getAttribute((isset($context["item"]) ? $context["item"] : null), "puntaje"));
                // line 160
                echo "\t\t";
            }
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['item'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        echo "\t\t
\t</table>
\t
</div>
</div>
<div id=\"content_footer\"></div>
<div id=\"footer\">
</div>


";
    }

    public function getTemplateName()
    {
        return "orgQuinielaBundle:Inicio:index.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  498 => 160,  496 => 159,  490 => 156,  486 => 155,  475 => 153,  471 => 152,  464 => 151,  456 => 149,  451 => 146,  446 => 145,  433 => 140,  431 => 139,  425 => 136,  421 => 135,  410 => 133,  406 => 132,  395 => 130,  391 => 129,  386 => 126,  366 => 118,  364 => 117,  358 => 114,  354 => 113,  347 => 112,  343 => 111,  339 => 110,  332 => 109,  328 => 108,  324 => 107,  319 => 104,  300 => 97,  292 => 93,  288 => 92,  281 => 91,  266 => 88,  262 => 87,  253 => 83,  248 => 82,  233 => 76,  231 => 75,  225 => 72,  210 => 69,  195 => 66,  191 => 65,  186 => 62,  174 => 56,  152 => 51,  148 => 50,  137 => 48,  630 => 160,  617 => 157,  611 => 156,  605 => 155,  596 => 154,  590 => 153,  584 => 152,  575 => 151,  569 => 150,  563 => 149,  558 => 146,  553 => 145,  546 => 140,  533 => 137,  527 => 136,  521 => 135,  512 => 134,  506 => 133,  500 => 132,  491 => 131,  485 => 130,  479 => 154,  460 => 150,  447 => 115,  441 => 114,  426 => 112,  420 => 111,  414 => 134,  405 => 109,  399 => 131,  388 => 104,  383 => 103,  375 => 97,  356 => 93,  350 => 92,  335 => 90,  329 => 89,  320 => 88,  308 => 86,  303 => 83,  291 => 77,  277 => 90,  271 => 72,  265 => 71,  256 => 70,  250 => 69,  244 => 68,  223 => 65,  218 => 62,  213 => 61,  206 => 68,  181 => 61,  172 => 50,  160 => 48,  145 => 46,  139 => 45,  134 => 42,  129 => 41,  110 => 32,  74 => 23,  52 => 15,  65 => 21,  23 => 1,  480 => 162,  474 => 126,  469 => 125,  461 => 155,  457 => 153,  453 => 151,  444 => 149,  440 => 148,  437 => 147,  435 => 113,  430 => 144,  427 => 143,  423 => 142,  413 => 134,  409 => 132,  407 => 131,  402 => 130,  398 => 129,  393 => 107,  387 => 122,  384 => 121,  381 => 125,  379 => 119,  374 => 116,  368 => 112,  365 => 111,  362 => 94,  360 => 109,  355 => 106,  341 => 91,  337 => 103,  322 => 101,  314 => 103,  312 => 98,  309 => 97,  305 => 95,  298 => 96,  294 => 90,  285 => 89,  283 => 88,  278 => 86,  268 => 85,  264 => 84,  258 => 86,  252 => 80,  247 => 78,  241 => 77,  229 => 66,  220 => 70,  214 => 70,  177 => 65,  169 => 60,  140 => 55,  132 => 51,  128 => 44,  111 => 37,  107 => 36,  61 => 19,  273 => 89,  269 => 94,  254 => 92,  246 => 90,  243 => 88,  240 => 86,  238 => 85,  235 => 67,  230 => 82,  227 => 81,  224 => 71,  221 => 71,  219 => 76,  217 => 75,  208 => 68,  204 => 72,  179 => 69,  159 => 61,  143 => 56,  135 => 53,  131 => 52,  119 => 41,  108 => 36,  102 => 30,  71 => 24,  67 => 22,  63 => 20,  59 => 14,  47 => 9,  201 => 92,  196 => 90,  183 => 82,  171 => 61,  166 => 55,  163 => 62,  158 => 67,  156 => 52,  151 => 47,  142 => 59,  138 => 54,  136 => 56,  123 => 43,  121 => 46,  117 => 40,  115 => 43,  105 => 40,  91 => 30,  69 => 21,  62 => 22,  49 => 14,  101 => 32,  94 => 28,  89 => 20,  85 => 27,  79 => 18,  75 => 17,  68 => 23,  56 => 9,  50 => 10,  87 => 28,  72 => 22,  66 => 24,  55 => 15,  31 => 5,  41 => 7,  28 => 5,  43 => 6,  35 => 2,  29 => 3,  38 => 6,  26 => 6,  25 => 4,  21 => 2,  24 => 3,  19 => 1,  98 => 31,  93 => 28,  88 => 26,  78 => 21,  46 => 7,  44 => 9,  40 => 7,  32 => 1,  27 => 4,  22 => 2,  209 => 82,  203 => 78,  199 => 67,  193 => 53,  189 => 71,  187 => 52,  182 => 66,  176 => 64,  173 => 65,  168 => 72,  164 => 54,  162 => 59,  154 => 58,  149 => 51,  147 => 58,  144 => 49,  141 => 49,  133 => 47,  130 => 41,  125 => 39,  122 => 43,  116 => 41,  112 => 42,  109 => 34,  106 => 33,  103 => 32,  99 => 31,  95 => 28,  92 => 28,  86 => 25,  82 => 22,  80 => 19,  73 => 25,  64 => 14,  60 => 21,  57 => 15,  54 => 10,  51 => 14,  48 => 8,  45 => 6,  42 => 5,  39 => 6,  36 => 5,  33 => 4,  30 => 3,);
    }
}
