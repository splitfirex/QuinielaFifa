INSERT INTO `Usuario`(`id`, `nombre`) VALUES (1, 'Daniel');
INSERT INTO `Usuario`(`id`, `nombre`) VALUES (2, 'Bruno');
INSERT INTO `Usuario`(`id`, `nombre`) VALUES (3, 'Adolfo');
INSERT INTO `Usuario`(`id`, `nombre`) VALUES (4, 'Rafa dos Santos');
INSERT INTO `Usuario`(`id`, `nombre`) VALUES (999, 'Admin');
