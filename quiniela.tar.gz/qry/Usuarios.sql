INSERT INTO `Usuario`(`id`, `nombre`) VALUES (1, 'Gallego');
INSERT INTO `Usuario`(`id`, `nombre`) VALUES (4, 'Rafa dos Santos');
INSERT INTO `Usuario`(`id`, `nombre`) VALUES (999, 'Admin');
