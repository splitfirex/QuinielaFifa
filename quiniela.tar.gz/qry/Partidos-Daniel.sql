INSERT INTO `Partido`(`numPartido`, `fecha`,`PaisHome`, `PaisVist`, `Usuario`,`home_score`, `vist_score`) 
			  VALUES (1, '2014-06-21 17:30',7,14,1,2,0);
INSERT INTO `Partido`(`numPartido`, `fecha`,`PaisHome`, `PaisVist`, `Usuario`,`home_score`, `vist_score`) 
			  VALUES (2, '2014-06-21 17:30',26,8,1,2,1);
INSERT INTO `Partido`(`numPartido`, `fecha`,`PaisHome`, `PaisVist`, `Usuario`,`home_score`, `vist_score`) 
			  VALUES (3, '2014-06-21 17:30',16,28,1,1,0);
INSERT INTO `Partido`(`numPartido`, `fecha`,`PaisHome`, `PaisVist`, `Usuario`,`home_score`, `vist_score`) 
			  VALUES (4, '2014-06-21 17:30',9,4,1,3,0);
INSERT INTO `Partido`(`numPartido`, `fecha`,`PaisHome`, `PaisVist`, `Usuario`,`home_score`, `vist_score`) 
			  VALUES (5, '2014-06-21 17:30',10,20,1,1,0);
INSERT INTO `Partido`(`numPartido`, `fecha`,`PaisHome`, `PaisVist`, `Usuario`,`home_score`, `vist_score`) 
			  VALUES (6, '2014-06-21 17:30',12,25,1,1,1);
INSERT INTO `Partido`(`numPartido`, `fecha`,`PaisHome`, `PaisVist`, `Usuario`,`home_score`, `vist_score`) 
			  VALUES (7, '2014-06-21 17:30',32,13,1,3,0);
INSERT INTO `Partido`(`numPartido`, `fecha`,`PaisHome`, `PaisVist`, `Usuario`,`home_score`, `vist_score`) 
			  VALUES (8, '2014-06-21 17:30',22,24,1,0,0);
INSERT INTO `Partido`(`numPartido`, `fecha`,`PaisHome`, `PaisVist`, `Usuario`,`home_score`, `vist_score`) 
			  VALUES (9, '2014-06-21 17:30',31,15,1,1,1);
INSERT INTO `Partido`(`numPartido`, `fecha`,`PaisHome`, `PaisVist`, `Usuario`,`home_score`, `vist_score`) 
			  VALUES (10, '2014-06-21 17:30',18,21,1,2,0);
INSERT INTO `Partido`(`numPartido`, `fecha`,`PaisHome`, `PaisVist`, `Usuario`,`home_score`, `vist_score`) 
			  VALUES (11, '2014-06-21 17:30',3,6,1,3,0);
INSERT INTO `Partido`(`numPartido`, `fecha`,`PaisHome`, `PaisVist`, `Usuario`,`home_score`, `vist_score`) 
			  VALUES (12, '2014-06-21 17:30',1,29,1,2,1);
INSERT INTO `Partido`(`numPartido`, `fecha`,`PaisHome`, `PaisVist`, `Usuario`,`home_score`, `vist_score`) 
			  VALUES (13, '2014-06-21 17:30',23,27,1,0,2);
INSERT INTO `Partido`(`numPartido`, `fecha`,`PaisHome`, `PaisVist`, `Usuario`,`home_score`, `vist_score`) 
			  VALUES (14, '2014-06-21 17:30',19,17,1,2,0);
INSERT INTO `Partido`(`numPartido`, `fecha`,`PaisHome`, `PaisVist`, `Usuario`,`home_score`, `vist_score`) 
			  VALUES (15, '2014-06-21 17:30',5,2,1,2,0);
INSERT INTO `Partido`(`numPartido`, `fecha`,`PaisHome`, `PaisVist`, `Usuario`,`home_score`, `vist_score`) 
			  VALUES (16, '2014-06-21 17:30',7,26,1,3,0);
INSERT INTO `Partido`(`numPartido`, `fecha`,`PaisHome`, `PaisVist`, `Usuario`,`home_score`, `vist_score`) 
			  VALUES (17, '2014-06-21 17:30',30,11,1,1,0);
INSERT INTO `Partido`(`numPartido`, `fecha`,`PaisHome`, `PaisVist`, `Usuario`,`home_score`, `vist_score`) 
			  VALUES (18, '2014-06-21 17:30',4,28,1,0,3);
INSERT INTO `Partido`(`numPartido`, `fecha`,`PaisHome`, `PaisVist`, `Usuario`,`home_score`, `vist_score`) 
			  VALUES (19, '2014-06-21 17:30',8,14,1,0,2);
INSERT INTO `Partido`(`numPartido`, `fecha`,`PaisHome`, `PaisVist`, `Usuario`,`home_score`, `vist_score`) 
			  VALUES (20, '2014-06-21 17:30',16,9,1,2,1);
INSERT INTO `Partido`(`numPartido`, `fecha`,`PaisHome`, `PaisVist`, `Usuario`,`home_score`, `vist_score`) 
			  VALUES (21, '2014-06-21 17:30',10,12,1,1,0);
INSERT INTO `Partido`(`numPartido`, `fecha`,`PaisHome`, `PaisVist`, `Usuario`,`home_score`, `vist_score`) 
			  VALUES (22, '2014-06-21 17:30',32,22,1,4,1);
INSERT INTO `Partido`(`numPartido`, `fecha`,`PaisHome`, `PaisVist`, `Usuario`,`home_score`, `vist_score`) 
			  VALUES (23, '2014-06-21 17:30',25,20,1,1,1);
INSERT INTO `Partido`(`numPartido`, `fecha`,`PaisHome`, `PaisVist`, `Usuario`,`home_score`, `vist_score`) 
			  VALUES (24, '2014-06-21 17:30',24,13,1,2,0);
INSERT INTO `Partido`(`numPartido`, `fecha`,`PaisHome`, `PaisVist`, `Usuario`,`home_score`, `vist_score`) 
			  VALUES (25, '2014-06-21 17:30',31,18,1,1,1);
INSERT INTO `Partido`(`numPartido`, `fecha`,`PaisHome`, `PaisVist`, `Usuario`,`home_score`, `vist_score`) 
			  VALUES (26, '2014-06-21 17:30',21,15,1,0,0);
INSERT INTO `Partido`(`numPartido`, `fecha`,`PaisHome`, `PaisVist`, `Usuario`,`home_score`, `vist_score`) 
			  VALUES (27, '2014-06-21 17:30',3,23,1,3,0);
INSERT INTO `Partido`(`numPartido`, `fecha`,`PaisHome`, `PaisVist`, `Usuario`,`home_score`, `vist_score`) 
			  VALUES (28, '2014-06-21 17:30',1,19,1,4,1);
INSERT INTO `Partido`(`numPartido`, `fecha`,`PaisHome`, `PaisVist`, `Usuario`,`home_score`, `vist_score`) 
			  VALUES (29, '2014-06-21 17:30',27,6,1,0,0);
INSERT INTO `Partido`(`numPartido`, `fecha`,`PaisHome`, `PaisVist`, `Usuario`,`home_score`, `vist_score`) 
			  VALUES (30, '2014-06-21 17:30',11,2,1,0,0);
INSERT INTO `Partido`(`numPartido`, `fecha`,`PaisHome`, `PaisVist`, `Usuario`,`home_score`, `vist_score`) 
			  VALUES (31, '2014-06-21 17:30',17,29,1,0,3);
INSERT INTO `Partido`(`numPartido`, `fecha`,`PaisHome`, `PaisVist`, `Usuario`,`home_score`, `vist_score`) 
			  VALUES (32, '2014-06-21 17:30',5,30,1,2,1);
INSERT INTO `Partido`(`numPartido`, `fecha`,`PaisHome`, `PaisVist`, `Usuario`,`home_score`, `vist_score`) 
			  VALUES (33, '2014-06-21 17:30',4,16,1,0,4);
INSERT INTO `Partido`(`numPartido`, `fecha`,`PaisHome`, `PaisVist`, `Usuario`,`home_score`, `vist_score`) 
			  VALUES (34, '2014-06-21 17:30',28,9,1,1,1);
INSERT INTO `Partido`(`numPartido`, `fecha`,`PaisHome`, `PaisVist`, `Usuario`,`home_score`, `vist_score`) 
			  VALUES (35, '2014-06-21 17:30',8,7,1,0,4);
INSERT INTO `Partido`(`numPartido`, `fecha`,`PaisHome`, `PaisVist`, `Usuario`,`home_score`, `vist_score`) 
			  VALUES (36, '2014-06-21 17:30',14,26,1,1,1);
INSERT INTO `Partido`(`numPartido`, `fecha`,`PaisHome`, `PaisVist`, `Usuario`,`home_score`, `vist_score`) 
			  VALUES (37, '2014-06-21 17:30',24,32,1,0,2);
INSERT INTO `Partido`(`numPartido`, `fecha`,`PaisHome`, `PaisVist`, `Usuario`,`home_score`, `vist_score`) 
			  VALUES (38, '2014-06-21 17:30',13,22,1,0,2);
INSERT INTO `Partido`(`numPartido`, `fecha`,`PaisHome`, `PaisVist`, `Usuario`,`home_score`, `vist_score`) 
			  VALUES (39, '2014-06-21 17:30',25,10,1,0,1);
INSERT INTO `Partido`(`numPartido`, `fecha`,`PaisHome`, `PaisVist`, `Usuario`,`home_score`, `vist_score`) 
			  VALUES (40, '2014-06-21 17:30',20,12,1,0,1);
INSERT INTO `Partido`(`numPartido`, `fecha`,`PaisHome`, `PaisVist`, `Usuario`,`home_score`, `vist_score`) 
			  VALUES (41, '2014-06-21 17:30',27,3,1,1,2);
INSERT INTO `Partido`(`numPartido`, `fecha`,`PaisHome`, `PaisVist`, `Usuario`,`home_score`, `vist_score`) 
			  VALUES (42, '2014-06-21 17:30',6,23,1,1,0);
INSERT INTO `Partido`(`numPartido`, `fecha`,`PaisHome`, `PaisVist`, `Usuario`,`home_score`, `vist_score`) 
			  VALUES (43, '2014-06-21 17:30',21,31,1,0,2);
INSERT INTO `Partido`(`numPartido`, `fecha`,`PaisHome`, `PaisVist`, `Usuario`,`home_score`, `vist_score`) 
			  VALUES (44, '2014-06-21 17:30',15,18,1,1,2);
INSERT INTO `Partido`(`numPartido`, `fecha`,`PaisHome`, `PaisVist`, `Usuario`,`home_score`, `vist_score`) 
			  VALUES (45, '2014-06-21 17:30',17,1,1,0,4);
INSERT INTO `Partido`(`numPartido`, `fecha`,`PaisHome`, `PaisVist`, `Usuario`,`home_score`, `vist_score`) 
			  VALUES (46, '2014-06-21 17:30',29,19,1,3,1);
INSERT INTO `Partido`(`numPartido`, `fecha`,`PaisHome`, `PaisVist`, `Usuario`,`home_score`, `vist_score`) 
			  VALUES (47, '2014-06-21 17:30',11,5,1,0,2);
INSERT INTO `Partido`(`numPartido`, `fecha`,`PaisHome`, `PaisVist`, `Usuario`,`home_score`, `vist_score`) 
			  VALUES (48, '2014-06-21 17:30',2,30,1,0,1);
INSERT INTO `Partido`(`numPartido`, `fecha`,`PaisHome`, `PaisVist`, `Usuario`,`home_score`, `vist_score`) 
			  VALUES (49, '2014-06-21 17:30',7,9,1,2,1);
INSERT INTO `Partido`(`numPartido`, `fecha`,`PaisHome`, `PaisVist`, `Usuario`,`home_score`, `vist_score`) 
			  VALUES (50, '2014-06-21 17:30',10,24,1,0,1);
INSERT INTO `Partido`(`numPartido`, `fecha`,`PaisHome`, `PaisVist`, `Usuario`,`home_score`, `vist_score`) 
			  VALUES (51, '2014-06-21 17:30',16,14,1,2,0);
INSERT INTO `Partido`(`numPartido`, `fecha`,`PaisHome`, `PaisVist`, `Usuario`,`home_score`, `vist_score`) 
			  VALUES (52, '2014-06-21 17:30',32,12,1,2,1);
INSERT INTO `Partido`(`numPartido`, `fecha`,`PaisHome`, `PaisVist`, `Usuario`,`home_score`, `vist_score`) 
			  VALUES (53, '2014-06-21 17:30',18,27,1,1,0);
INSERT INTO `Partido`(`numPartido`, `fecha`,`PaisHome`, `PaisVist`, `Usuario`,`home_score`, `vist_score`) 
			  VALUES (54, '2014-06-21 17:30',1,30,1,3,1);
INSERT INTO `Partido`(`numPartido`, `fecha`,`PaisHome`, `PaisVist`, `Usuario`,`home_score`, `vist_score`) 
			  VALUES (55, '2014-06-21 17:30',3,31,1,2,1);
INSERT INTO `Partido`(`numPartido`, `fecha`,`PaisHome`, `PaisVist`, `Usuario`,`home_score`, `vist_score`) 
			  VALUES (56, '2014-06-21 17:30',5,29,1,3,4);
INSERT INTO `Partido`(`numPartido`, `fecha`,`PaisHome`, `PaisVist`, `Usuario`,`home_score`, `vist_score`) 
			  VALUES (57, '2014-06-21 17:30',7,24,1,3,1);
INSERT INTO `Partido`(`numPartido`, `fecha`,`PaisHome`, `PaisVist`, `Usuario`,`home_score`, `vist_score`) 
			  VALUES (58, '2014-06-21 17:30',18,1,1,0,2);
INSERT INTO `Partido`(`numPartido`, `fecha`,`PaisHome`, `PaisVist`, `Usuario`,`home_score`, `vist_score`) 
			  VALUES (59, '2014-06-21 17:30',16,32,1,1,0);
INSERT INTO `Partido`(`numPartido`, `fecha`,`PaisHome`, `PaisVist`, `Usuario`,`home_score`, `vist_score`) 
			  VALUES (60, '2014-06-21 17:30',3,29,1,1,0);
INSERT INTO `Partido`(`numPartido`, `fecha`,`PaisHome`, `PaisVist`, `Usuario`,`home_score`, `vist_score`) 
			  VALUES (61, '2014-06-21 17:30',7,1,1,4,3);
INSERT INTO `Partido`(`numPartido`, `fecha`,`PaisHome`, `PaisVist`, `Usuario`,`home_score`, `vist_score`) 
			  VALUES (62, '2014-06-21 17:30',16,3,1,2,0);
INSERT INTO `Partido`(`numPartido`, `fecha`,`PaisHome`, `PaisVist`, `Usuario`,`home_score`, `vist_score`) 
			  VALUES (63, '2014-06-21 17:30',1,3,1,2,1);
INSERT INTO `Partido`(`numPartido`, `fecha`,`PaisHome`, `PaisVist`, `Usuario`,`home_score`, `vist_score`) 
			  VALUES (64, '2014-06-21 17:30',7,16,1,0,1);
