USE quiniela;
truncate Partido;
INSERT INTO `Partido`(`numPartido`, `fecha`,`PaisHome`, `PaisVist`, `Usuario`) 
			  VALUES (1, '2014-06-12 15:30',7,14,999);
INSERT INTO `Partido`(`numPartido`, `fecha`,`PaisHome`, `PaisVist`, `Usuario`) 
			  VALUES (2, '2014-06-13 11:30',26,8,999);
INSERT INTO `Partido`(`numPartido`, `fecha`,`PaisHome`, `PaisVist`, `Usuario`) 
			  VALUES (3, '2014-06-13 14:30',16,28,999);
INSERT INTO `Partido`(`numPartido`, `fecha`,`PaisHome`, `PaisVist`, `Usuario`) 
			  VALUES (4, '2014-06-13 17:30',9,4,999);
