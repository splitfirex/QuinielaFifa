USE quiniela;
truncate Partido;
INSERT INTO `Partido`(`numPartido`, `fecha`,`PaisHome`, `PaisVist`, `Usuario`,`jugado`) 
			  VALUES (1, '2014-06-12 15:30',7,14,999,false);
INSERT INTO `Partido`(`numPartido`, `fecha`,`PaisHome`, `PaisVist`, `Usuario`,`jugado`) 
			  VALUES (2, '2014-06-13 11:30',26,8,999,false);
INSERT INTO `Partido`(`numPartido`, `fecha`,`PaisHome`, `PaisVist`, `Usuario`,`jugado`) 
			  VALUES (3, '2014-06-13 14:30',16,28,999,false);
INSERT INTO `Partido`(`numPartido`, `fecha`,`PaisHome`, `PaisVist`, `Usuario`,`jugado`) 
			  VALUES (4, '2014-06-13 17:30',9,4,999,false);
INSERT INTO `Partido`(`numPartido`, `fecha`,`PaisHome`, `PaisVist`, `Usuario`,`jugado`) 
			  VALUES (5, '2014-06-14 11:30',10,20,999,false);
INSERT INTO `Partido`(`numPartido`, `fecha`,`PaisHome`, `PaisVist`, `Usuario`,`jugado`) 
			  VALUES (6, '2014-06-14 20:30',12,25,999,false);
INSERT INTO `Partido`(`numPartido`, `fecha`,`PaisHome`, `PaisVist`, `Usuario`,`jugado`) 
			  VALUES (7, '2014-06-14 14:30',32,13,999,false);
INSERT INTO `Partido`(`numPartido`, `fecha`,`PaisHome`, `PaisVist`, `Usuario`,`jugado`) 
			  VALUES (8, '2014-06-14 17:30',22,24,999,false);
INSERT INTO `Partido`(`numPartido`, `fecha`,`PaisHome`, `PaisVist`, `Usuario`,`jugado`) 
			  VALUES (9, '2014-06-15 11:30',31,15,999,false);
INSERT INTO `Partido`(`numPartido`, `fecha`,`PaisHome`, `PaisVist`, `Usuario`,`jugado`) 
			  VALUES (10, '2014-06-15 14:30',18,21,999,false);
INSERT INTO `Partido`(`numPartido`, `fecha`,`PaisHome`, `PaisVist`, `Usuario`,`jugado`) 
			  VALUES (11, '2014-06-15 17:30',3,6,999,false);
INSERT INTO `Partido`(`numPartido`, `fecha`,`PaisHome`, `PaisVist`, `Usuario`,`jugado`) 
			  VALUES (12, '2014-06-16 11:30',1,29,999,false);
INSERT INTO `Partido`(`numPartido`, `fecha`,`PaisHome`, `PaisVist`, `Usuario`,`jugado`) 
			  VALUES (13, '2014-06-16 14:30',23,27,999,false);
INSERT INTO `Partido`(`numPartido`, `fecha`,`PaisHome`, `PaisVist`, `Usuario`,`jugado`) 
			  VALUES (14, '2014-06-16 17:30',19,17,999,false);
INSERT INTO `Partido`(`numPartido`, `fecha`,`PaisHome`, `PaisVist`, `Usuario`,`jugado`) 
			  VALUES (15, '2014-06-17 11:30',5,2,999,false);
INSERT INTO `Partido`(`numPartido`, `fecha`,`PaisHome`, `PaisVist`, `Usuario`,`jugado`) 
			  VALUES (16, '2014-06-17 14:30',7,26,999,false);
INSERT INTO `Partido`(`numPartido`, `fecha`,`PaisHome`, `PaisVist`, `Usuario`,`jugado`) 
			  VALUES (17, '2014-06-17 17:30',30,11,999,false);
INSERT INTO `Partido`(`numPartido`, `fecha`,`PaisHome`, `PaisVist`, `Usuario`,`jugado`) 
			  VALUES (18, '2014-06-18 11:30',4,28,999,false);
INSERT INTO `Partido`(`numPartido`, `fecha`,`PaisHome`, `PaisVist`, `Usuario`,`jugado`) 
			  VALUES (19, '2014-06-18 17:30',8,14,999,false);
INSERT INTO `Partido`(`numPartido`, `fecha`,`PaisHome`, `PaisVist`, `Usuario`,`jugado`) 
			  VALUES (20, '2014-06-18 14:30',16,9,999,false);
INSERT INTO `Partido`(`numPartido`, `fecha`,`PaisHome`, `PaisVist`, `Usuario`,`jugado`) 
			  VALUES (21, '2014-06-19 11:30',10,12,999,false);
INSERT INTO `Partido`(`numPartido`, `fecha`,`PaisHome`, `PaisVist`, `Usuario`,`jugado`) 
			  VALUES (22, '2014-06-19 14:30',32,22,999,false);
INSERT INTO `Partido`(`numPartido`, `fecha`,`PaisHome`, `PaisVist`, `Usuario`,`jugado`) 
			  VALUES (23, '2014-06-19 17:30',25,20,999,false);
INSERT INTO `Partido`(`numPartido`, `fecha`,`PaisHome`, `PaisVist`, `Usuario`,`jugado`) 
			  VALUES (24, '2014-06-20 11:30',24,13,999,false);
INSERT INTO `Partido`(`numPartido`, `fecha`,`PaisHome`, `PaisVist`, `Usuario`,`jugado`) 
			  VALUES (25, '2014-06-20 14:30',31,18,999,false);
INSERT INTO `Partido`(`numPartido`, `fecha`,`PaisHome`, `PaisVist`, `Usuario`,`jugado`) 
			  VALUES (26, '2014-06-20 17:30',21,15,999,false);
INSERT INTO `Partido`(`numPartido`, `fecha`,`PaisHome`, `PaisVist`, `Usuario`,`jugado`) 
			  VALUES (27, '2014-06-21 11:30',3,23,999,false);
INSERT INTO `Partido`(`numPartido`, `fecha`,`PaisHome`, `PaisVist`, `Usuario`,`jugado`) 
			  VALUES (28, '2014-06-21 14:30',1,19,999,false);
INSERT INTO `Partido`(`numPartido`, `fecha`,`PaisHome`, `PaisVist`, `Usuario`,`jugado`) 
			  VALUES (29, '2014-06-21 17:30',27,6,999,false);
INSERT INTO `Partido`(`numPartido`, `fecha`,`PaisHome`, `PaisVist`, `Usuario`,`jugado`) 
			  VALUES (30, '2014-06-22 14:30',11,2,999,false);
INSERT INTO `Partido`(`numPartido`, `fecha`,`PaisHome`, `PaisVist`, `Usuario`,`jugado`) 
			  VALUES (31, '2014-06-22 17:30',17,29,999,false);
INSERT INTO `Partido`(`numPartido`, `fecha`,`PaisHome`, `PaisVist`, `Usuario`,`jugado`) 
			  VALUES (32, '2014-06-22 11:30',5,30,999,false);
INSERT INTO `Partido`(`numPartido`, `fecha`,`PaisHome`, `PaisVist`, `Usuario`,`jugado`) 
			  VALUES (33, '2014-06-23 11:30',4,16,999,false);
INSERT INTO `Partido`(`numPartido`, `fecha`,`PaisHome`, `PaisVist`, `Usuario`,`jugado`) 
			  VALUES (34, '2014-06-23 11:30',28,9,999,false);
INSERT INTO `Partido`(`numPartido`, `fecha`,`PaisHome`, `PaisVist`, `Usuario`,`jugado`) 
			  VALUES (35, '2014-06-23 15:30',8,7,999,false);
INSERT INTO `Partido`(`numPartido`, `fecha`,`PaisHome`, `PaisVist`, `Usuario`,`jugado`) 
			  VALUES (36, '2014-06-23 15:30',14,26,999,false);
INSERT INTO `Partido`(`numPartido`, `fecha`,`PaisHome`, `PaisVist`, `Usuario`,`jugado`) 
			  VALUES (37, '2014-06-24 11:30',24,32,999,false);
INSERT INTO `Partido`(`numPartido`, `fecha`,`PaisHome`, `PaisVist`, `Usuario`,`jugado`) 
			  VALUES (38, '2014-06-24 11:30',13,22,999,false);
INSERT INTO `Partido`(`numPartido`, `fecha`,`PaisHome`, `PaisVist`, `Usuario`,`jugado`) 
			  VALUES (39, '2014-06-24 15:30',25,10,999,false);
INSERT INTO `Partido`(`numPartido`, `fecha`,`PaisHome`, `PaisVist`, `Usuario`,`jugado`) 
			  VALUES (40, '2014-06-24 15:30',20,12,999,false);
INSERT INTO `Partido`(`numPartido`, `fecha`,`PaisHome`, `PaisVist`, `Usuario`,`jugado`) 
			  VALUES (41, '2014-06-25 11:30',27,3,999,false);
INSERT INTO `Partido`(`numPartido`, `fecha`,`PaisHome`, `PaisVist`, `Usuario`,`jugado`) 
			  VALUES (42, '2014-06-25 11:30',6,23,999,false);
INSERT INTO `Partido`(`numPartido`, `fecha`,`PaisHome`, `PaisVist`, `Usuario`,`jugado`) 
			  VALUES (43, '2014-06-25 15:30',21,31,999,false);
INSERT INTO `Partido`(`numPartido`, `fecha`,`PaisHome`, `PaisVist`, `Usuario`,`jugado`) 
			  VALUES (44, '2014-06-25 15:30',15,18,999,false);
INSERT INTO `Partido`(`numPartido`, `fecha`,`PaisHome`, `PaisVist`, `Usuario`,`jugado`) 
			  VALUES (45, '2014-06-26 11:30',17,1,999,false);
INSERT INTO `Partido`(`numPartido`, `fecha`,`PaisHome`, `PaisVist`, `Usuario`,`jugado`) 
			  VALUES (46, '2014-06-26 11:30',29,19,999,false);
INSERT INTO `Partido`(`numPartido`, `fecha`,`PaisHome`, `PaisVist`, `Usuario`,`jugado`) 
			  VALUES (47, '2014-06-26 15:30',11,5,999,false);
INSERT INTO `Partido`(`numPartido`, `fecha`,`PaisHome`, `PaisVist`, `Usuario`,`jugado`) 
			  VALUES (48, '2014-06-26 15:30',2,30,999,false);
INSERT INTO `Partido`(`numPartido`, `fecha`,`PaisHome`, `PaisVist`, `Usuario`,`jugado`) 
			  VALUES (49, '2014-6-28 11:30',99,99,999,false);
INSERT INTO `Partido`(`numPartido`, `fecha`,`PaisHome`, `PaisVist`, `Usuario`,`jugado`) 
			  VALUES (50, '2014-6-28 15:30',99,99,999,false);
INSERT INTO `Partido`(`numPartido`, `fecha`,`PaisHome`, `PaisVist`, `Usuario`,`jugado`) 
			  VALUES (51, '2014-6-29 11:30',99,99,999,false);
INSERT INTO `Partido`(`numPartido`, `fecha`,`PaisHome`, `PaisVist`, `Usuario`,`jugado`) 
			  VALUES (52, '2014-6-29 15:30',99,99,999,false);
INSERT INTO `Partido`(`numPartido`, `fecha`,`PaisHome`, `PaisVist`, `Usuario`,`jugado`) 
			  VALUES (53, '2014-6-30 11:30',99,99,999,false);
INSERT INTO `Partido`(`numPartido`, `fecha`,`PaisHome`, `PaisVist`, `Usuario`,`jugado`) 
			  VALUES (54, '2014-6-30 15:30',99,99,999,false);
INSERT INTO `Partido`(`numPartido`, `fecha`,`PaisHome`, `PaisVist`, `Usuario`,`jugado`) 
			  VALUES (55, '2014-7-1 11:30',99,99,999,false);
INSERT INTO `Partido`(`numPartido`, `fecha`,`PaisHome`, `PaisVist`, `Usuario`,`jugado`) 
			  VALUES (56, '2014-7-1 15:30',99,99,999,false);
INSERT INTO `Partido`(`numPartido`, `fecha`,`PaisHome`, `PaisVist`, `Usuario`,`jugado`) 
			  VALUES (57, '2014-7-4 15:30',99,99,999,false);
INSERT INTO `Partido`(`numPartido`, `fecha`,`PaisHome`, `PaisVist`, `Usuario`,`jugado`) 
			  VALUES (58, '2014-7-4 11:30',99,99,999,false);
INSERT INTO `Partido`(`numPartido`, `fecha`,`PaisHome`, `PaisVist`, `Usuario`,`jugado`) 
			  VALUES (59, '2014-7-5 15:30',99,99,999,false);
INSERT INTO `Partido`(`numPartido`, `fecha`,`PaisHome`, `PaisVist`, `Usuario`,`jugado`) 
			  VALUES (60, '2014-7-5 11:30',99,99,999,false);
INSERT INTO `Partido`(`numPartido`, `fecha`,`PaisHome`, `PaisVist`, `Usuario`,`jugado`) 
			  VALUES (61, '2014-7-8 15:30',99,99,999,false);
INSERT INTO `Partido`(`numPartido`, `fecha`,`PaisHome`, `PaisVist`, `Usuario`,`jugado`) 
			  VALUES (62, '2014-7-9 15:30',99,99,999,false);
INSERT INTO `Partido`(`numPartido`, `fecha`,`PaisHome`, `PaisVist`, `Usuario`,`jugado`) 
			  VALUES (63, '2014-7-12 15:30',99,99,999,false);
INSERT INTO `Partido`(`numPartido`, `fecha`,`PaisHome`, `PaisVist`, `Usuario`,`jugado`) 
			  VALUES (64, '2014-7-13 14:30',99,99,999,false);

