INSERT INTO `Partido`(`numPartido`, `fecha`,`PaisHome`, `PaisVist`, `Usuario`,`home_score`, `vist_score`) 
			  VALUES (1, '2014-06-21 17:30',7,14,2, 1,1);
INSERT INTO `Partido`(`numPartido`, `fecha`,`PaisHome`, `PaisVist`, `Usuario`,`home_score`, `vist_score`) 
			  VALUES (2, '2014-06-21 17:30',26,8,2, 1,1);
INSERT INTO `Partido`(`numPartido`, `fecha`,`PaisHome`, `PaisVist`, `Usuario`,`home_score`, `vist_score`) 
			  VALUES (3, '2014-06-21 17:30',16,28,2, 2,1);
INSERT INTO `Partido`(`numPartido`, `fecha`,`PaisHome`, `PaisVist`, `Usuario`,`home_score`, `vist_score`) 
			  VALUES (4, '2014-06-21 17:30',9,4,2, 1,0);
INSERT INTO `Partido`(`numPartido`, `fecha`,`PaisHome`, `PaisVist`, `Usuario`,`home_score`, `vist_score`) 
			  VALUES (5, '2014-06-21 17:30',10,20,2, 1,1);
INSERT INTO `Partido`(`numPartido`, `fecha`,`PaisHome`, `PaisVist`, `Usuario`,`home_score`, `vist_score`) 
			  VALUES (6, '2014-06-21 17:30',12,25,2, 0,0);
INSERT INTO `Partido`(`numPartido`, `fecha`,`PaisHome`, `PaisVist`, `Usuario`,`home_score`, `vist_score`) 
			  VALUES (7, '2014-06-21 17:30',32,13,2, 3,0);
INSERT INTO `Partido`(`numPartido`, `fecha`,`PaisHome`, `PaisVist`, `Usuario`,`home_score`, `vist_score`) 
			  VALUES (8, '2014-06-21 17:30',22,24,2, 0,0);
INSERT INTO `Partido`(`numPartido`, `fecha`,`PaisHome`, `PaisVist`, `Usuario`,`home_score`, `vist_score`) 
			  VALUES (9, '2014-06-21 17:30',31,15,2, 1,1);
INSERT INTO `Partido`(`numPartido`, `fecha`,`PaisHome`, `PaisVist`, `Usuario`,`home_score`, `vist_score`) 
			  VALUES (10, '2014-06-21 17:30',18,21,2, 2,0);
INSERT INTO `Partido`(`numPartido`, `fecha`,`PaisHome`, `PaisVist`, `Usuario`,`home_score`, `vist_score`) 
			  VALUES (11, '2014-06-21 17:30',3,6,2, 2,1);
INSERT INTO `Partido`(`numPartido`, `fecha`,`PaisHome`, `PaisVist`, `Usuario`,`home_score`, `vist_score`) 
			  VALUES (12, '2014-06-21 17:30',1,29,2, 1,1);
INSERT INTO `Partido`(`numPartido`, `fecha`,`PaisHome`, `PaisVist`, `Usuario`,`home_score`, `vist_score`) 
			  VALUES (13, '2014-06-21 17:30',23,27,2, 1,1);
INSERT INTO `Partido`(`numPartido`, `fecha`,`PaisHome`, `PaisVist`, `Usuario`,`home_score`, `vist_score`) 
			  VALUES (14, '2014-06-21 17:30',19,17,2, 2,0);
INSERT INTO `Partido`(`numPartido`, `fecha`,`PaisHome`, `PaisVist`, `Usuario`,`home_score`, `vist_score`) 
			  VALUES (15, '2014-06-21 17:30',5,2,2, 3,1);
INSERT INTO `Partido`(`numPartido`, `fecha`,`PaisHome`, `PaisVist`, `Usuario`,`home_score`, `vist_score`) 
			  VALUES (16, '2014-06-21 17:30',7,26,2, 2,1);
INSERT INTO `Partido`(`numPartido`, `fecha`,`PaisHome`, `PaisVist`, `Usuario`,`home_score`, `vist_score`) 
			  VALUES (17, '2014-06-21 17:30',30,11,2, 1,0);
INSERT INTO `Partido`(`numPartido`, `fecha`,`PaisHome`, `PaisVist`, `Usuario`,`home_score`, `vist_score`) 
			  VALUES (18, '2014-06-21 17:30',4,28,2, 1,3);
INSERT INTO `Partido`(`numPartido`, `fecha`,`PaisHome`, `PaisVist`, `Usuario`,`home_score`, `vist_score`) 
			  VALUES (19, '2014-06-21 17:30',8,14,2, 1,3);
INSERT INTO `Partido`(`numPartido`, `fecha`,`PaisHome`, `PaisVist`, `Usuario`,`home_score`, `vist_score`) 
			  VALUES (20, '2014-06-21 17:30',16,9,2, 2,2);
INSERT INTO `Partido`(`numPartido`, `fecha`,`PaisHome`, `PaisVist`, `Usuario`,`home_score`, `vist_score`) 
			  VALUES (21, '2014-06-21 17:30',10,12,2, 2,2);
INSERT INTO `Partido`(`numPartido`, `fecha`,`PaisHome`, `PaisVist`, `Usuario`,`home_score`, `vist_score`) 
			  VALUES (22, '2014-06-21 17:30',32,22,2, 3,1);
INSERT INTO `Partido`(`numPartido`, `fecha`,`PaisHome`, `PaisVist`, `Usuario`,`home_score`, `vist_score`) 
			  VALUES (23, '2014-06-21 17:30',25,20,2, 2,0);
INSERT INTO `Partido`(`numPartido`, `fecha`,`PaisHome`, `PaisVist`, `Usuario`,`home_score`, `vist_score`) 
			  VALUES (24, '2014-06-21 17:30',24,13,2, 2,0);
INSERT INTO `Partido`(`numPartido`, `fecha`,`PaisHome`, `PaisVist`, `Usuario`,`home_score`, `vist_score`) 
			  VALUES (25, '2014-06-21 17:30',31,18,2, 0,0);
INSERT INTO `Partido`(`numPartido`, `fecha`,`PaisHome`, `PaisVist`, `Usuario`,`home_score`, `vist_score`) 
			  VALUES (26, '2014-06-21 17:30',21,15,2, 0,0);
INSERT INTO `Partido`(`numPartido`, `fecha`,`PaisHome`, `PaisVist`, `Usuario`,`home_score`, `vist_score`) 
			  VALUES (27, '2014-06-21 17:30',3,23,2, 4,0);
INSERT INTO `Partido`(`numPartido`, `fecha`,`PaisHome`, `PaisVist`, `Usuario`,`home_score`, `vist_score`) 
			  VALUES (28, '2014-06-21 17:30',1,19,2, 3,2);
INSERT INTO `Partido`(`numPartido`, `fecha`,`PaisHome`, `PaisVist`, `Usuario`,`home_score`, `vist_score`) 
			  VALUES (29, '2014-06-21 17:30',27,6,2, 1,1);
INSERT INTO `Partido`(`numPartido`, `fecha`,`PaisHome`, `PaisVist`, `Usuario`,`home_score`, `vist_score`) 
			  VALUES (30, '2014-06-21 17:30',11,2,2, 1,2);
INSERT INTO `Partido`(`numPartido`, `fecha`,`PaisHome`, `PaisVist`, `Usuario`,`home_score`, `vist_score`) 
			  VALUES (31, '2014-06-21 17:30',17,29,2, 0,2);
INSERT INTO `Partido`(`numPartido`, `fecha`,`PaisHome`, `PaisVist`, `Usuario`,`home_score`, `vist_score`) 
			  VALUES (32, '2014-06-21 17:30',5,30,2, 2,1);
INSERT INTO `Partido`(`numPartido`, `fecha`,`PaisHome`, `PaisVist`, `Usuario`,`home_score`, `vist_score`) 
			  VALUES (33, '2014-06-21 17:30',4,16,2, 0,2);
INSERT INTO `Partido`(`numPartido`, `fecha`,`PaisHome`, `PaisVist`, `Usuario`,`home_score`, `vist_score`) 
			  VALUES (34, '2014-06-21 17:30',28,9,2, 2,2);
INSERT INTO `Partido`(`numPartido`, `fecha`,`PaisHome`, `PaisVist`, `Usuario`,`home_score`, `vist_score`) 
			  VALUES (35, '2014-06-21 17:30',8,7,2, 0,2);
INSERT INTO `Partido`(`numPartido`, `fecha`,`PaisHome`, `PaisVist`, `Usuario`,`home_score`, `vist_score`) 
			  VALUES (36, '2014-06-21 17:30',14,26,2, 1,1);
INSERT INTO `Partido`(`numPartido`, `fecha`,`PaisHome`, `PaisVist`, `Usuario`,`home_score`, `vist_score`) 
			  VALUES (37, '2014-06-21 17:30',24,32,2, 0,0);
INSERT INTO `Partido`(`numPartido`, `fecha`,`PaisHome`, `PaisVist`, `Usuario`,`home_score`, `vist_score`) 
			  VALUES (38, '2014-06-21 17:30',13,22,2, 0,2);
INSERT INTO `Partido`(`numPartido`, `fecha`,`PaisHome`, `PaisVist`, `Usuario`,`home_score`, `vist_score`) 
			  VALUES (39, '2014-06-21 17:30',25,10,2, 1,2);
INSERT INTO `Partido`(`numPartido`, `fecha`,`PaisHome`, `PaisVist`, `Usuario`,`home_score`, `vist_score`) 
			  VALUES (40, '2014-06-21 17:30',20,12,2, 2,1);
INSERT INTO `Partido`(`numPartido`, `fecha`,`PaisHome`, `PaisVist`, `Usuario`,`home_score`, `vist_score`) 
			  VALUES (41, '2014-06-21 17:30',27,3,2, 1,3);
INSERT INTO `Partido`(`numPartido`, `fecha`,`PaisHome`, `PaisVist`, `Usuario`,`home_score`, `vist_score`) 
			  VALUES (42, '2014-06-21 17:30',6,23,2, 1,0);
INSERT INTO `Partido`(`numPartido`, `fecha`,`PaisHome`, `PaisVist`, `Usuario`,`home_score`, `vist_score`) 
			  VALUES (43, '2014-06-21 17:30',21,31,2, 1,2);
INSERT INTO `Partido`(`numPartido`, `fecha`,`PaisHome`, `PaisVist`, `Usuario`,`home_score`, `vist_score`) 
			  VALUES (44, '2014-06-21 17:30',15,18,2, 1,1);
INSERT INTO `Partido`(`numPartido`, `fecha`,`PaisHome`, `PaisVist`, `Usuario`,`home_score`, `vist_score`) 
			  VALUES (45, '2014-06-21 17:30',17,1,2, 1,3);
INSERT INTO `Partido`(`numPartido`, `fecha`,`PaisHome`, `PaisVist`, `Usuario`,`home_score`, `vist_score`) 
			  VALUES (46, '2014-06-21 17:30',29,19,2, 1,1);
INSERT INTO `Partido`(`numPartido`, `fecha`,`PaisHome`, `PaisVist`, `Usuario`,`home_score`, `vist_score`) 
			  VALUES (47, '2014-06-21 17:30',11,5,2, 0,2);
INSERT INTO `Partido`(`numPartido`, `fecha`,`PaisHome`, `PaisVist`, `Usuario`,`home_score`, `vist_score`) 
			  VALUES (48, '2014-06-21 17:30',2,30,2, 1,2);
INSERT INTO `Partido`(`numPartido`, `fecha`,`PaisHome`, `PaisVist`, `Usuario`,`home_score`, `vist_score`) 
			  VALUES (49, '2014-06-21 17:30',7,9,2, 3,2);
INSERT INTO `Partido`(`numPartido`, `fecha`,`PaisHome`, `PaisVist`, `Usuario`,`home_score`, `vist_score`) 
			  VALUES (50, '2014-06-21 17:30',10,24,2, 1,2);
INSERT INTO `Partido`(`numPartido`, `fecha`,`PaisHome`, `PaisVist`, `Usuario`,`home_score`, `vist_score`) 
			  VALUES (51, '2014-06-21 17:30',16,14,2, 2,0);
INSERT INTO `Partido`(`numPartido`, `fecha`,`PaisHome`, `PaisVist`, `Usuario`,`home_score`, `vist_score`) 
			  VALUES (52, '2014-06-21 17:30',32,25,2, 3,1);
INSERT INTO `Partido`(`numPartido`, `fecha`,`PaisHome`, `PaisVist`, `Usuario`,`home_score`, `vist_score`) 
			  VALUES (53, '2014-06-21 17:30',18,6,2, 2,0);
INSERT INTO `Partido`(`numPartido`, `fecha`,`PaisHome`, `PaisVist`, `Usuario`,`home_score`, `vist_score`) 
			  VALUES (54, '2014-06-21 17:30',1,30,2, 2,1);
INSERT INTO `Partido`(`numPartido`, `fecha`,`PaisHome`, `PaisVist`, `Usuario`,`home_score`, `vist_score`) 
			  VALUES (55, '2014-06-21 17:30',3,31,2, 3,1);
INSERT INTO `Partido`(`numPartido`, `fecha`,`PaisHome`, `PaisVist`, `Usuario`,`home_score`, `vist_score`) 
			  VALUES (56, '2014-06-21 17:30',5,29,2, 3,1);
INSERT INTO `Partido`(`numPartido`, `fecha`,`PaisHome`, `PaisVist`, `Usuario`,`home_score`, `vist_score`) 
			  VALUES (57, '2014-06-21 17:30',7,24,2, 1,0);
INSERT INTO `Partido`(`numPartido`, `fecha`,`PaisHome`, `PaisVist`, `Usuario`,`home_score`, `vist_score`) 
			  VALUES (58, '2014-06-21 17:30',18,1,2, 0,1);
INSERT INTO `Partido`(`numPartido`, `fecha`,`PaisHome`, `PaisVist`, `Usuario`,`home_score`, `vist_score`) 
			  VALUES (59, '2014-06-21 17:30',16,32,2, 0,1);
INSERT INTO `Partido`(`numPartido`, `fecha`,`PaisHome`, `PaisVist`, `Usuario`,`home_score`, `vist_score`) 
			  VALUES (60, '2014-06-21 17:30',3,5,2, 1,0);
INSERT INTO `Partido`(`numPartido`, `fecha`,`PaisHome`, `PaisVist`, `Usuario`,`home_score`, `vist_score`) 
			  VALUES (61, '2014-06-21 17:30',7,1,2, 2,0);
INSERT INTO `Partido`(`numPartido`, `fecha`,`PaisHome`, `PaisVist`, `Usuario`,`home_score`, `vist_score`) 
			  VALUES (62, '2014-06-21 17:30',32,3,2, 1,2);
INSERT INTO `Partido`(`numPartido`, `fecha`,`PaisHome`, `PaisVist`, `Usuario`,`home_score`, `vist_score`) 
			  VALUES (63, '2014-06-21 17:30',1,32,2, 0,1);
INSERT INTO `Partido`(`numPartido`, `fecha`,`PaisHome`, `PaisVist`, `Usuario`,`home_score`, `vist_score`) 
			  VALUES (64, '2014-06-21 17:30',7,3,2, 0,1);


