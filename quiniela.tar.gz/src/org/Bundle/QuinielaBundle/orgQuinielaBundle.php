<?php

namespace org\Bundle\QuinielaBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class orgQuinielaBundle extends Bundle
{
}
