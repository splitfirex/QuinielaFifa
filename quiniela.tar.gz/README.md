Quiniela en Symfony para el mundial 2014
